$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Ensure-Templates {
    $templateDir = Join-Path $PSScriptRoot "templates"
    New-Item -ItemType Directory -Force -Path $templateDir | Out-Null

    $templateNames = @(
        "404.html",
        "base.html",
        "channel.html",
        "channel_tile.html",
        "channels.html",
        "index.html",
        "settings.html",
        "video.html",
        "video_tile.html"
    )

    foreach ($name in $templateNames) {
        $target = Join-Path $templateDir $name
        if (-not (Test-Path $target) -or (Get-Item $target).Length -lt 10) {
            $url = "https://raw.githubusercontent.com/MCJack123/yt-dvr/refs/tags/0.3.0/templates/$name"
            Write-Host "Downloading yt-dvr template: $name"
            Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $target
            if (-not (Test-Path $target) -or (Get-Item $target).Length -lt 10) {
                throw "Could not download template $name"
            }
        }
    }
    return $templateDir
}

$venvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPython)) {
    throw "Run START_YT_DLP_DVR.bat once first so .venv and Deno are installed."
}

# Refresh the portable plugin copy before building. Frozen yt-dlp builds do
# not discover pip/PYTHONPATH plugins; they do discover exe-dir\yt-dlp-plugins.
Write-Host "Refreshing portable yt-dlp PO plugin directory..."
& $venvPython (Join-Path $PSScriptRoot "sync_po_plugin.py")
if ($LASTEXITCODE -ne 0) { throw "Could not prepare portable bgutil yt-dlp plugin" }
$portablePlugins = Join-Path $PSScriptRoot "yt-dlp-plugins"
$portableBgutil = Join-Path $portablePlugins "bgutil-ytdlp-pot-provider\yt_dlp_plugins\extractor\getpot_bgutil_script.py"
if (-not (Test-Path $portableBgutil)) { throw "Portable bgutil plugin file is missing: $portableBgutil" }

Write-Host "Installing/updating PyInstaller..."
& $venvPython -m pip install --upgrade pyinstaller
if ($LASTEXITCODE -ne 0) { throw "Could not install PyInstaller" }

$tools = Join-Path $PSScriptRoot "tools"
$deno = Join-Path $tools "deno.exe"
if (-not (Test-Path $deno)) { throw "tools\deno.exe is missing. Run START_YT_DLP_DVR.bat first." }

$poVersion = "1.3.1"
$poRoot = Join-Path $tools "bgutil-ytdlp-pot-provider-$poVersion"
$poServer = Join-Path $poRoot "server"
$poMarker = Join-Path $poServer ".ytdvr-deno-ready-v0.4.30-$poVersion"
if (-not (Test-Path $poMarker)) {
    throw "Automatic PO Token provider is not prepared. Run START_YT_DLP_DVR.bat once and let the bgutil/Deno setup finish before building."
}
$poRuntimeDeps = @(
    (Join-Path $poServer "node_modules\axios\package.json"),
    (Join-Path $poServer "node_modules\form-data\package.json"),
    (Join-Path $poServer "node_modules\basic-ftp\package.json")
)
foreach ($dep in $poRuntimeDeps) {
    if (-not (Test-Path $dep)) {
        throw "Automatic PO Token dependency tree is incomplete: $dep. Run START_YT_DLP_DVR.bat once to rebuild bgutil node_modules before building."
    }
}
$ftpVersion = (Get-Content -Raw -Path (Join-Path $poServer "node_modules\basic-ftp\package.json") | ConvertFrom-Json).version
if ([version]$ftpVersion -lt [version]"5.2.1") {
    throw "Automatic PO Token dependency tree still contains basic-ftp $ftpVersion. Run START_YT_DLP_DVR.bat to complete the v0.4.30 security refresh."
}

# Use the already prepared tools\ffmpeg.exe when it exists. Do NOT overwrite it
# during a build: Windows locks an executable while yt-dvr/FFmpeg is using it,
# which made v0.4.6 fail with Copy-Item "file is being used by another process".
New-Item -ItemType Directory -Force -Path $tools | Out-Null
$ffmpegTarget = Join-Path $tools "ffmpeg.exe"
if (-not (Test-Path $ffmpegTarget)) {
    # Ignore a possible IMAGEIO_FFMPEG_EXE override so we get imageio-ffmpeg's
    # packaged binary instead of accidentally resolving back to tools\ffmpeg.exe.
    $ffmpeg = (& $venvPython -c "import os; os.environ.pop('IMAGEIO_FFMPEG_EXE', None); import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())").Trim()
    if ([string]::IsNullOrWhiteSpace($ffmpeg) -or -not (Test-Path $ffmpeg)) {
        throw "Bundled FFmpeg could not be found."
    }
    Copy-Item -Force $ffmpeg $ffmpegTarget
} else {
    Write-Host "Using existing tools\ffmpeg.exe (not overwriting it during build)."
}

# v0.4.1 tried pathlib.Path(yt_dvr.__file__), but yt_dvr is a namespace package
# in the PyPI wheel and yt_dvr.__file__ is None. Use the local official
# template copy instead. This is also how upstream's documented PyInstaller
# command packages templates.
$templateDir = Ensure-Templates

# Sanity checks before spending time in PyInstaller.
& $venvPython -c "import asyncio; asyncio.EventLoop=getattr(asyncio,'EventLoop',asyncio.AbstractEventLoop); import yt_dvr.__main__, yt_dlp, pytchat, PIL; print('Python dependencies OK')"
if ($LASTEXITCODE -ne 0) { throw "yt-dvr dependency import test failed." }

$sep = ";"  # Windows PyInstaller --add-data / --add-binary separator
$pyiArgs = @(
    "-m", "PyInstaller",
    "--noconfirm", "--clean", "--onefile",
    "--name", "yt-dlp-dvr",
    "--paths", $PSScriptRoot,
    "--add-data", "$templateDir${sep}templates",
    "--add-binary", "$ffmpegTarget${sep}.",
    "--add-binary", "$deno${sep}.",
    "--collect-submodules", "yt_dvr",
    "--collect-all", "curl_cffi",
    "--collect-all", "dateutil",
    "--collect-all", "pytchat",
    "--collect-all", "PIL",
    "--collect-all", "yt_dlp",
    "--copy-metadata", "yt-dlp",
    "--copy-metadata", "yt-dvr",
    (Join-Path $PSScriptRoot "run_yt_dlp_dvr.py")
)

Write-Host ""
Write-Host "Building yt-dlp-dvr.exe..."
& $venvPython @pyiArgs
if ($LASTEXITCODE -ne 0) { throw "PyInstaller failed with code $LASTEXITCODE" }

$built = Join-Path $PSScriptRoot "dist\yt-dlp-dvr.exe"
if (-not (Test-Path $built)) { throw "PyInstaller reported success, but the EXE was not found: $built" }

# The bgutil generation source stays external so the one-file EXE does not have
# to unpack the npm/Deno dependency tree on every launch.
$distTools = Join-Path $PSScriptRoot "dist\tools"
New-Item -ItemType Directory -Force -Path $distTools | Out-Null
$distPoRoot = Join-Path $distTools "bgutil-ytdlp-pot-provider-$poVersion"
if (Test-Path $distPoRoot) { Remove-Item -Recurse -Force $distPoRoot }
Copy-Item -Recurse -Force $poRoot $distPoRoot

# CRITICAL v0.4.13 fix: copy the Python provider plugin to yt-dlp's documented
# portable plugin directory beside the EXE. This is what a PyInstaller build
# actually discovers; a plugin installed only in pip/PYTHONPATH is ignored.
$distPlugins = Join-Path $PSScriptRoot "dist\yt-dlp-plugins"
if (Test-Path $distPlugins) { Remove-Item -Recurse -Force $distPlugins }
Copy-Item -Recurse -Force $portablePlugins $distPlugins

# Run the actual frozen EXE's corrected non-network PO readiness test. This
# proves that yt-dlp registers bgutil:script-deno, Deno 2+ runs, and the bgutil
# server files are present. It intentionally does not call provider.is_available().
Write-Host ""
Write-Host "Running frozen EXE PO Token self-test..."
& $built --po-self-test-only
if ($LASTEXITCODE -ne 0) {
    throw "Built EXE could not load/prepare the external bgutil PO provider (self-test code $LASTEXITCODE)."
}

Write-Host ""
Write-Host "Build successful."
Write-Host "Built: $built"
Write-Host "PO self-test: PASSED"
Write-Host ""
Write-Host "Keep BOTH dist\tools and dist\yt-dlp-plugins beside the EXE. Put ytdvr_config.json/ytdvr.db beside the EXE if you want to reuse them."
