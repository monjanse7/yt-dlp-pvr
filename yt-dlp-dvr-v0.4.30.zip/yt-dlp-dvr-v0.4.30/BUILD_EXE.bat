@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo Building yt-dlp dvr v0.4.30 EXE
echo ================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_exe.ps1"
set ERR=%ERRORLEVEL%
echo.
if "%ERR%"=="0" (
  echo Finished. Look in the dist folder for yt-dlp-dvr.exe
) else (
  echo Build failed with code %ERR%.
)
pause
exit /b %ERR%
