"""
yt-dlp dvr reconnect/runtime patch

Adds a reconnect grace period for YouTube live recordings while keeping one
RecordingInfo/database row and one final recording file.

Designed for yt-dvr 0.3.0.
SPDX-License-Identifier: AGPL-3.0-or-later
"""

from __future__ import annotations

__author__ = "monjanse7"
__version__ = "0.4.30"

from copy import copy, deepcopy
from typing import Any, Optional, cast
from urllib import request
from urllib.error import URLError
import asyncio
import datetime
import hashlib
import io
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time

from yt_dlp import YoutubeDL, utils
from dateutil import parser as dateparser

import yt_dvr.channel as channel_mod
from yt_dvr.channel import RecordingInfo
from yt_dvr.config import config

LOG = logging.getLogger("yt-dvr")

RECONNECT_DELAY_SECONDS = 5
DEFAULT_LIVE_FORMAT = "bv*+ba/b"
OFFLINE_GRACE_SECONDS = 180
DEFAULT_BOT_BACKOFF_SECONDS = 300
PO_PROVIDER_VERSION = "1.3.1"


def _chat_progress(message: str, *args: object) -> None:
    """Emit chat-render progress even when yt-dvr's INFO logger is hidden.

    The standalone recovery tool sets YTDVR_CHAT_PROGRESS_STDOUT=1 so long
    frame-preparation and FFmpeg stages are always visible in CMD. Normal
    yt-dvr runs continue to use the application's logger.
    """
    if args:
        try:
            text = message % args
        except Exception:
            text = " ".join([message, *(str(x) for x in args)])
    else:
        text = message
    if os.environ.get("YTDVR_CHAT_PROGRESS_STDOUT") == "1":
        print(text, flush=True)
    else:
        LOG.info("%s", text)

_ORIGINAL_CHANNEL_DOWNLOAD = None
_ORIGINAL_CHANNEL_CHECK_LIVE = None
_ORIGINAL_RECORDING_DELETE = None
_ORIGINAL_RECORDING_DUMP = None
_PATCHED = False
_PYTCHAT_CLIENT_PATCHED = False


def _is_youtube_platform(platform: str | None) -> bool:
    return bool(platform and "youtube" in platform.lower())


def _looks_like_youtube_url(url: str | None) -> bool:
    value = (url or "").lower()
    return "youtube.com" in value or "youtu.be" in value


def _expected_not_live_message(message: object) -> bool:
    """True only for yt-dlp's normal YouTube channel-offline status.

    yt-dlp reports ``UserNotLive`` through its error logger, even though an
    offline channel is an expected state for a DVR monitor.  We keep the
    extractor exception/return behaviour unchanged and only change how that
    expected status is presented in the console.
    """
    text = str(message or "").lower()
    return "youtube" in text and "not currently live" in text


def _expected_upcoming_live_message(message: object) -> bool:
    """True for YouTube's normal pre-live/upcoming status.

    yt-dlp reports scheduled live events that have not started yet through
    its error logger (for example, "This live event will begin in a few
    moments").  For a DVR monitor this is an expected transitional state,
    not an application error.
    """
    text = str(message or "").lower()
    return (
        "youtube" in text
        and (
            "this live event will begin in" in text
            or "this live event will begin shortly" in text
        )
    )


class _LivenessYTDLPLogger:
    """Route yt-dlp liveness output through yt-dvr's logger.

    Normal yt-dlp errors remain ERROR.  Expected monitoring states
    (``UserNotLive`` and an upcoming event that has not started yet) are
    demoted to INFO, and their diagnostic traceback noise is hidden.
    """

    def __init__(self, channel_url: str):
        self.channel_url = channel_url
        self._hide_expected_trace_until = 0.0

    def _clean(self, message: object) -> str:
        return str(message or "").replace("\r", "").rstrip("\n")

    def debug(self, message: object) -> None:
        text = self._clean(message)
        if not text:
            return
        if time.monotonic() < self._hide_expected_trace_until:
            lowered = text.lower()
            if (
                "traceback" in lowered
                or "usernotlive" in lowered
                or 'file "yt_dlp' in lowered
                or "raise usernotlive" in lowered
            ):
                return
        # yt-dlp's custom logger API sends ordinary informational messages to
        # debug() too.  Only messages explicitly prefixed [debug] are DEBUG.
        if text.startswith("[debug]"):
            LOG.debug("%s", text)
        else:
            LOG.info("%s", text)

    def info(self, message: object) -> None:
        text = self._clean(message)
        if text:
            LOG.info("%s", text)

    def warning(self, message: object) -> None:
        text = self._clean(message)
        if text:
            LOG.warning("%s", text)

    def _is_expected_liveness_trace(self, text: str) -> bool:
        """Return True only for tracebacks tied to expected liveness states.

        yt-dlp can emit a human-readable status in one logger.error() call and
        then a Python stack in a second call.  Suppress that second call only
        inside the short expected-state window; genuine yt-dlp failures remain
        visible.
        """
        lowered = text.lower()
        if "usernotlive" in lowered or "raise usernotlive" in lowered:
            return True
        if (
            "this live event will begin in" in lowered
            or "this live event will begin shortly" in lowered
        ):
            return True
        traceback_shaped = (
            text.lstrip().startswith('File "')
            or text.lstrip().startswith('Traceback (most recent call last):')
            or '\n  File "' in text
        )
        yt_dlp_frame = (
            "yt_dlp\\extractor\\common.py" in lowered
            or "yt_dlp/extractor/common.py" in lowered
            or "yt_dlp\\extractor\\youtube\\_tab.py" in lowered
            or "yt_dlp/extractor/youtube/_tab.py" in lowered
            or "yt_dlp\\extractor\\youtube\\_video.py" in lowered
            or "yt_dlp/extractor/youtube/_video.py" in lowered
        )
        return traceback_shaped and yt_dlp_frame

    def error(self, message: object) -> None:
        text = self._clean(message)
        if not text:
            return
        if _expected_not_live_message(text):
            self._hide_expected_trace_until = time.monotonic() + 5.0
            match = re.search(r"\[youtube:tab\]\s+([^:]+):", text, flags=re.I)
            target = match.group(1).strip() if match else self.channel_url
            LOG.info("YouTube channel %s is not currently live", target)
            return
        if _expected_upcoming_live_message(text):
            self._hide_expected_trace_until = time.monotonic() + 5.0
            match = re.search(r"\[youtube\]\s+([^:]+):", text, flags=re.I)
            video_id = match.group(1).strip() if match else "scheduled event"
            LOG.info(
                "YouTube live event %s is upcoming and will begin shortly",
                video_id,
            )
            return
        if (
            time.monotonic() < self._hide_expected_trace_until
            and self._is_expected_liveness_trace(text)
        ):
            return
        LOG.error("%s", text)


def _po_server_home() -> Optional[str]:
    value = os.environ.get("YTDVR_PO_SERVER_HOME")
    if value and os.path.isdir(value):
        return os.path.abspath(value)
    return None


def _deno_path() -> Optional[str]:
    explicit = os.environ.get("YTDVR_DENO_PATH")
    if explicit and os.path.isfile(explicit):
        return os.path.abspath(explicit)
    if hasattr(sys, "_MEIPASS"):
        candidate = os.path.join(str(sys._MEIPASS), "deno.exe")  # type: ignore[attr-defined]
        if os.path.isfile(candidate):
            return candidate
    found = shutil.which("deno") or shutil.which("deno.exe")
    return found


def _boolish(value: object, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    return str(value).strip().lower() not in {"", "0", "false", "no", "off", "disabled"}


def _special_ytdvr_options(raw_params: Optional[dict]) -> dict[str, Any]:
    raw = raw_params or {}
    po_default = _boolish(os.environ.get("YTDVR_PO_DEFAULT", "1"), True)
    return {
        "po_enabled": _boolish(raw.get("_ytdvr_po_token"), po_default),
        "po_client": str(raw.get("_ytdvr_po_client") or "mweb"),
        "bot_backoff": max(0, int(raw.get("_ytdvr_bot_backoff_seconds") or DEFAULT_BOT_BACKOFF_SECONDS)),
        # Chat post-processing is intentionally opt-in.  TXT + JSONL recording
        # remains unchanged whenever Get chat is enabled.
        "chat_embed_track": _boolish(raw.get("_ytdvr_chat_embed_track"), False),
        "chat_burn_overlay": _boolish(raw.get("_ytdvr_chat_burn_overlay"), False),
        "chat_overlay_seconds": max(2, min(120, int(raw.get("_ytdvr_chat_overlay_seconds") or 20))),
        "chat_overlay_lines": max(2, min(14, int(raw.get("_ytdvr_chat_overlay_lines") or 8))),
        "chat_overlay_theme": str(raw.get("_ytdvr_chat_overlay_theme") or "dark").lower(),
        "chat_overlay_avatars": _boolish(raw.get("_ytdvr_chat_overlay_avatars"), True),
        "chat_overlay_badges": _boolish(raw.get("_ytdvr_chat_overlay_badges"), True),
        "chat_overlay_superchat": _boolish(raw.get("_ytdvr_chat_overlay_superchat"), True),
        "chat_overlay_width": max(360, min(760, int(raw.get("_ytdvr_chat_overlay_width") or 520))),
        # v0.4.30 defaults to a cool 2-thread encode so long overlay jobs do
        # not peg every CPU core and heat the PC unnecessarily.
        "chat_cpu_profile": str(raw.get("_ytdvr_chat_cpu_profile") or "cool").lower(),
    }


def _merge_extractor_arg(params: dict[str, Any], extractor: str, key: str, values: list[str]) -> None:
    extractor_args = params.get("extractor_args")
    if not isinstance(extractor_args, dict):
        extractor_args = {}
        params["extractor_args"] = extractor_args
    ext = extractor_args.get(extractor)
    if not isinstance(ext, dict):
        ext = {}
        extractor_args[extractor] = ext
    ext[key] = values


def _prepare_ytdl_params(raw_params: Optional[dict], *, youtube: bool) -> dict[str, Any]:
    """Return params safe to pass to YoutubeDL, injecting automatic POT support.

    Keys beginning with ``_ytdvr_`` are UI/private controls and are removed
    before the dictionary reaches yt-dlp.
    """
    params = deepcopy(raw_params or {})
    options = _special_ytdvr_options(raw_params)
    for key in list(params):
        if str(key).startswith("_ytdvr_"):
            params.pop(key, None)

    deno = _deno_path()
    if deno:
        runtimes = params.get("js_runtimes")
        if not isinstance(runtimes, dict):
            runtimes = {}
            params["js_runtimes"] = runtimes
        runtimes.setdefault("deno", {"path": deno})

    if youtube and options["po_enabled"]:
        server_home = _po_server_home()
        plugin_active = _boolish(os.environ.get("YTDVR_PO_PLUGIN_ACTIVE"), False)
        if server_home and plugin_active:
            _merge_extractor_arg(params, "youtube", "player_client", [options["po_client"]])
            _merge_extractor_arg(params, "youtubepot-bgutilscript", "server_home", [server_home])
        else:
            # Do not force mweb unless the actual yt-dlp plugin loader and the
            # bgutil script-deno provider passed v0.4.13's stable readiness checks.
            LOG.debug(
                "Automatic PO Token requested, but provider readiness checks are not active "
                "(server_home=%s, plugin_active=%s)",
                bool(server_home),
                plugin_active,
            )
    return params




def _apply_runtime_paths(params: dict[str, Any]) -> dict[str, Any]:
    """Apply FFmpeg/Deno paths before YoutubeDL is constructed.

    yt-dlp's extractor/runtime configuration is most reliable when the API
    parameters are complete at YoutubeDL construction time.  Do not overwrite
    an existing js_runtimes mapping; merge the portable Deno path into it.
    """
    deno = _deno_path()
    if deno:
        runtimes = params.get("js_runtimes")
        if not isinstance(runtimes, dict):
            runtimes = {}
            params["js_runtimes"] = runtimes
        deno_cfg = runtimes.get("deno")
        if not isinstance(deno_cfg, dict):
            deno_cfg = {}
            runtimes["deno"] = deno_cfg
        if not deno_cfg.get("path"):
            deno_cfg["path"] = deno

    if hasattr(sys, "_MEIPASS"):
        ffmpeg = os.path.join(str(sys._MEIPASS), "ffmpeg.exe")  # type: ignore[attr-defined]
        if os.path.isfile(ffmpeg):
            params.setdefault("ffmpeg_location", ffmpeg)
    elif config.ffmpegPath is not None:
        params.setdefault("ffmpeg_location", config.ffmpegPath)
    return params


def _prepared_profile(raw_params: Optional[dict], *, youtube: bool, purpose: str) -> dict[str, Any]:
    """Build the complete YoutubeDL API profile used by every pipeline stage."""
    params = _prepare_ytdl_params(raw_params, youtube=youtube)
    _apply_runtime_paths(params)
    if LOG.isEnabledFor(logging.DEBUG):
        # Mirror `yt-dlp -v` while debugging so provider/runtime discovery can
        # be verified in the same console as yt-dvr.
        params.setdefault("verbose", True)
        opts = _special_ytdvr_options(raw_params)
        extractor_args = params.get("extractor_args") if isinstance(params.get("extractor_args"), dict) else {}
        yt_args = extractor_args.get("youtube", {}) if isinstance(extractor_args, dict) else {}
        pot_args = extractor_args.get("youtubepot-bgutilscript", {}) if isinstance(extractor_args, dict) else {}
        LOG.debug(
            "Prepared yt-dlp profile for %s: youtube=%s cookiefile=%s deno=%s po=%s player_client=%s server_home=%s",
            purpose,
            youtube,
            bool(params.get("cookiefile")),
            bool((params.get("js_runtimes") or {}).get("deno") if isinstance(params.get("js_runtimes"), dict) else False),
            bool(youtube and opts["po_enabled"] and _boolish(os.environ.get("YTDVR_PO_PLUGIN_ACTIVE"), False)),
            yt_args.get("player_client") if isinstance(yt_args, dict) else None,
            bool(pot_args.get("server_home")) if isinstance(pot_args, dict) else False,
        )
    return params


def _youtube_video_id_from_error(exc: BaseException) -> Optional[str]:
    """Extract the 11-character YouTube video ID that yt-dlp already resolved.

    A channel ``/@handle/live`` extraction can resolve the current watch video
    before a later player request hits an auth/bot challenge.  yt-dlp includes
    that ID in DownloadError text (e.g. ``[youtube] ABC123...: Sign in...``).
    Retrying the exact watch URL mirrors the manual command that is known to
    work with the PO profile.
    """
    text = str(exc)
    matches = re.findall(r"\[youtube(?:[^\]]*)\]\s+([0-9A-Za-z_-]{11})(?=[:\s])", text)
    return matches[-1] if matches else None


def _info_is_live(info: object) -> bool:
    if not isinstance(info, dict):
        return False
    return bool(info.get("is_live")) or str(info.get("live_status") or "") == "is_live"


def _direct_watch_url(video_id: str) -> str:
    return f"https://www.youtube.com/watch?v={video_id}"


def _extract_direct_watch(
    raw_params: Optional[dict],
    video_id: str,
    *,
    purpose: str,
    quiet_probe: bool = True,
) -> tuple[YoutubeDL, dict]:
    """Extract a known watch URL with the same cookies + Deno + mweb + PO profile."""
    params = _prepared_profile(raw_params, youtube=True, purpose=purpose)
    params["skip_download"] = True
    if quiet_probe and LOG.level > logging.DEBUG:
        params["quiet"] = True
        params["noprogress"] = True
    dl = YoutubeDL(params)
    try:
        info = dl.extract_info(_direct_watch_url(video_id), download=False)
        if not isinstance(info, dict):
            raise utils.DownloadError(f"Direct watch extraction returned no info for {video_id}")
        return dl, info
    except BaseException:
        try:
            dl.close()
        except Exception:
            pass
        raise

def _is_auth_or_bot_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    markers = (
        "sign in to confirm you’re not a bot",
        "sign in to confirm you're not a bot",
        "sign in to confirm your age",
        "confirm you are not a bot",
        "confirm you're not a bot",
        "confirm you’re not a bot",
    )
    return any(marker in text for marker in markers)


def _candidate_paths(base_path: str) -> list[str]:
    """Return likely yt-dlp output paths for a requested TS path."""
    candidates = [
        base_path,
        base_path + ".part",
        base_path + ".mp4",
        base_path + ".mp4.part",
        base_path.replace(".ts", ".mp4"),
        base_path.replace(".ts", ".mp4.part"),
    ]
    # Preserve order while removing duplicates.
    seen: set[str] = set()
    result: list[str] = []
    for path in candidates:
        if path not in seen:
            seen.add(path)
            result.append(path)
    return result


def _find_output(base_path: str) -> Optional[str]:
    for path in _candidate_paths(base_path):
        try:
            if os.path.isfile(path) and os.path.getsize(path) > 0:
                return path
        except OSError:
            pass
    return None


def _append_file(source: str, destination: str) -> int:
    """Append source bytes to destination, then remove source."""
    if os.path.abspath(source) == os.path.abspath(destination):
        return 0
    os.makedirs(os.path.dirname(destination), exist_ok=True)
    before = os.path.getsize(destination) if os.path.exists(destination) else 0
    with open(destination, "ab") as dst, open(source, "rb") as src:
        shutil.copyfileobj(src, dst, length=4 * 1024 * 1024)
        dst.flush()
    try:
        os.remove(source)
    except OSError:
        pass
    return max(0, os.path.getsize(destination) - before)


TS_PACKET_SIZE = 188
LIVE_APPEND_POLL_SECONDS = 0.35


def _is_probably_mpegts(path: str) -> bool:
    """Return True only when a growing reconnect file looks like MPEG-TS.

    Live appending an MP4 fragment into a TS recording would corrupt the output,
    so v0.4.30 only tails files after observing the normal 0x47 sync byte at
    two consecutive 188-byte packet boundaries. Non-TS outputs still use the
    old end-of-attempt remux/append fallback.
    """
    try:
        if not os.path.isfile(path) or os.path.getsize(path) < TS_PACKET_SIZE * 2:
            return False
        with open(path, "rb") as handle:
            probe = handle.read(TS_PACKET_SIZE * 2 + 1)
        return len(probe) >= TS_PACKET_SIZE * 2 and probe[0] == 0x47 and probe[TS_PACKET_SIZE] == 0x47
    except OSError:
        return False


def _tail_safe_reconnect_source(base_path: str, copied: int = 0) -> Optional[str]:
    """Find the current TS/.part file produced by one reconnect attempt."""
    best: Optional[str] = None
    best_size = -1
    for path in _candidate_paths(base_path):
        lower = path.lower()
        if ".mp4" in lower:
            continue
        try:
            size = os.path.getsize(path) if os.path.isfile(path) else -1
        except OSError:
            continue
        if size < 0:
            continue
        # Before the first copied byte, require a real TS signature. After the
        # file has been verified once, a .part -> final rename can be followed
        # by offset without probing the beginning again.
        if copied == 0 and not _is_probably_mpegts(path):
            continue
        if size >= copied and size > best_size:
            best = path
            best_size = size
    return best


class _LiveTsAppender:
    """Tail a reconnect .ts.part into the one main recording while it grows."""

    def __init__(self, source_base: str, destination: str, attempt: int):
        self.source_base = source_base
        self.destination = destination
        self.attempt = attempt
        self.copied = 0
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._started_log = False
        self._lock = threading.Lock()

    def start(self) -> None:
        parent = os.path.dirname(self.destination)
        if parent:
            os.makedirs(parent, exist_ok=True)
        # Make the canonical recording visible immediately, even when the first
        # yt-dlp attempt produced no bytes. Explorer will then show one .ts file
        # growing while the reconnect worker is active.
        try:
            with open(self.destination, "ab"):
                pass
        except OSError as exc:
            LOG.warning("Could not prepare main recording for live append: %s", exc)
        self._thread = threading.Thread(
            target=self._run,
            name=f"yt-dvr-live-append-{self.attempt:04d}",
            daemon=True,
        )
        self._thread.start()

    def _run(self) -> None:
        while not self._stop_event.wait(LIVE_APPEND_POLL_SECONDS):
            try:
                self._pump(final=False)
            except BaseException as exc:
                LOG.debug("Live reconnect append pump failed temporarily: %s", exc)

    def _pump(self, *, final: bool) -> int:
        with self._lock:
            source = _tail_safe_reconnect_source(self.source_base, self.copied)
            if source is None:
                return 0
            try:
                size = os.path.getsize(source)
            except OSError:
                return 0
            available = size - self.copied
            if available <= 0:
                return 0

            # While yt-dlp is still writing, only copy complete MPEG-TS packets.
            # On final drain we copy the remaining bytes too.
            to_copy = available if final else (available // TS_PACKET_SIZE) * TS_PACKET_SIZE
            if to_copy <= 0:
                return 0

            written = 0
            try:
                with open(source, "rb") as src, open(self.destination, "ab") as dst:
                    src.seek(self.copied)
                    remaining = to_copy
                    while remaining > 0:
                        chunk = src.read(min(4 * 1024 * 1024, remaining))
                        if not chunk:
                            break
                        dst.write(chunk)
                        written += len(chunk)
                        remaining -= len(chunk)
                    dst.flush()
            except (OSError, PermissionError):
                # Windows can briefly deny a read while yt-dlp/FFmpeg renames or
                # replaces the .part file. The next pump follows the same offset.
                return 0

            self.copied += written
            if written and not self._started_log:
                self._started_log = True
                LOG.info(
                    "Live append active for reconnect %04d: writing directly into %s",
                    self.attempt,
                    self.destination,
                )
            return written

    def stop_and_drain(self) -> int:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=3)
        # yt-dlp may rename .part to the final .ts immediately before return.
        # Drain repeatedly so that rename/flush races do not leave tail bytes.
        for _ in range(4):
            before = self.copied
            self._pump(final=True)
            if self.copied == before:
                time.sleep(0.05)
            else:
                continue
        return self.copied

    def cleanup_sources(self) -> None:
        for path in _candidate_paths(self.source_base):
            if ".mp4" in path.lower():
                continue
            try:
                if os.path.isfile(path):
                    os.remove(path)
            except OSError:
                pass


def _normalize_first_output(self: RecordingInfo) -> None:
    """Make sure the initial attempt is stored at self.filename."""
    main_path = os.path.join(config.saveDir, self.filename)
    if os.path.isfile(main_path):
        return
    candidate = _find_output(main_path)
    if candidate is None:
        return
    if os.path.abspath(candidate) == os.path.abspath(main_path):
        return
    try:
        os.replace(candidate, main_path)
    except OSError:
        _append_file(candidate, main_path)


def _make_ytdl_params(self: RecordingInfo, out_path: str) -> dict[str, Any]:
    params = _prepared_profile(
        deepcopy(getattr(self, "_reconnect_base_params", {}) or {}),
        youtube=True,
        purpose="reconnect download",
    )
    params["format"] = getattr(self, "_reconnect_format", None) or DEFAULT_LIVE_FORMAT
    params["outtmpl"] = {"default": out_path}
    params["hls_use_mpegts"] = True
    params["wait_for_video"] = (2, 5)

    if not ("noprogress" in params) and LOG.level > logging.DEBUG:
        params["noprogress"] = True
    if not ("quiet" in params) and LOG.level > logging.DEBUG:
        params["quiet"] = True

    _apply_runtime_paths(params)

    # Keep upstream's anti-hang FFmpeg arguments.
    external = params.setdefault("external_downloader_args", {})
    if isinstance(external, dict):
        ffargs = external.setdefault("ffmpeg", [])
        if isinstance(ffargs, list):
            if "-rw_timeout" not in ffargs:
                ffargs.extend(["-rw_timeout", "15000000"])
            if "-seg_max_retry" not in ffargs:
                ffargs.extend(["-seg_max_retry", "20"])
    return params


def _probe_same_stream(self: RecordingInfo) -> tuple[str, Optional[dict]]:
    """Probe the current stream without letting a /live bot challenge end it.

    First try the channel monitor URL.  If yt-dlp fails there, retry the known
    direct watch URL for the existing stream ID using the exact same prepared
    cookies + Deno + mweb + bgutil profile.
    """
    raw_params = deepcopy(getattr(self, "_reconnect_base_params", {}) or {})
    params = _prepared_profile(raw_params, youtube=True, purpose="reconnect liveness")
    params.update({
        "quiet": True,
        "noprogress": True,
        "skip_download": True,
        "retries": 1,
        "fragment_retries": 1,
        "extractor_retries": 1,
        "socket_timeout": 15,
    })
    params.pop("wait_for_video", None)

    expected_id = str(getattr(self, "_reconnect_stream_id", "") or "")
    dl = YoutubeDL(params)
    monitor_exc: Optional[BaseException] = None
    try:
        info = dl.extract_info(getattr(self, "_reconnect_monitor_url", self.url), download=False)
        if isinstance(info, dict):
            found_id = str(info.get("id") or "")
            if _info_is_live(info) and expected_id and found_id == expected_id:
                return ("same_live", info)
            if _info_is_live(info) and expected_id and found_id and found_id != expected_id:
                return ("different", info)
            return ("offline", info)
    except utils.DownloadError as exc:
        monitor_exc = exc
        LOG.debug("Channel /live reconnect probe failed: %s", exc)
    except BaseException as exc:
        monitor_exc = exc
        LOG.debug("Reconnect liveness probe failed: %s", exc)
    finally:
        try:
            dl.close()
        except Exception:
            pass

    # v0.4.30: a direct watch URL is the authoritative fallback for the stream
    # we are already recording.  This avoids treating a /live auth challenge as
    # offline when the direct mweb+PO extraction still works.
    if expected_id:
        try:
            direct_dl, info = _extract_direct_watch(
                raw_params, expected_id, purpose="reconnect direct-watch fallback"
            )
            try:
                found_id = str(info.get("id") or "")
                if _info_is_live(info) and found_id == expected_id:
                    LOG.info("Direct-watch PO reconnect probe confirmed stream %s is still live", expected_id)
                    return ("same_live", info)
                if _info_is_live(info) and found_id and found_id != expected_id:
                    return ("different", info)
                return ("offline", info)
            finally:
                try:
                    direct_dl.close()
                except Exception:
                    pass
        except BaseException as exc:
            LOG.debug("Direct-watch reconnect probe failed for %s: %s", expected_id, exc)

    if monitor_exc is not None:
        LOG.debug("Reconnect probe ultimately treated stream as offline after monitor error: %s", monitor_exc)
    return ("offline", None)

def _ensure_mpegts_segment(source: str) -> Optional[str]:
    """Return a TS-compatible file, remuxing MP4-like reconnect output if needed."""
    lower = source.lower()
    if ".mp4" not in lower:
        return source

    converted = source + ".mpegts.ts"
    try:
        ffmpeg_mod = channel_mod.ffmpeg
        cmd = config.ffmpegPath if config.ffmpegPath is not None else channel_mod.FFMPEG_PATH
        (
            ffmpeg_mod
            .input(filename=source)
            .output(
                filename=converted,
                f="mpegts",
                codec="copy",
                extra_options={
                    "y": True,
                    "loglevel": config.logLevel.lower(),
                    "hide_banner": True,
                },
            )
            .run(cmd=cmd)
        )
        try:
            os.remove(source)
        except OSError:
            pass
        return converted
    except BaseException as exc:
        LOG.error("Could not convert reconnect segment to MPEG-TS: %s", exc)
        return None


def _download_one_reconnect_segment(self: RecordingInfo, attempt: int) -> bool:
    """Reconnect the same livestream while appending TS bytes to one main file.

    v0.4.30 keeps yt-dlp's reconnect output isolated in a temporary file, but a
    background tailer copies complete MPEG-TS packets into the canonical
    recording while that temporary .part is still growing. This preserves the
    safe format fallbacks while making the main .ts grow continuously.
    """
    main_path = os.path.join(config.saveDir, self.filename)
    # Keep downloader scratch files out of the normal channel folder. The user
    # sees one canonical .ts recording growing there while reconnect scratch
    # data lives under a private save-root directory.
    temp_dir = os.path.join(config.saveDir, ".yt-dlp-dvr-temp", self.channel)
    os.makedirs(temp_dir, exist_ok=True)
    temp_base = os.path.join(
        temp_dir,
        os.path.basename(self.filename) + f".reconnect-{attempt:04d}.ts",
    )

    def cleanup_temp_dir() -> None:
        try:
            if os.path.isdir(temp_dir) and not os.listdir(temp_dir):
                os.rmdir(temp_dir)
            root = os.path.dirname(temp_dir)
            if os.path.isdir(root) and not os.listdir(root):
                os.rmdir(root)
        except OSError:
            pass

    base_params = _make_ytdl_params(self, temp_base)
    requested_format = base_params.get("format") or DEFAULT_LIVE_FORMAT
    format_candidates = []
    for selector in (requested_format, DEFAULT_LIVE_FORMAT, "b"):
        if selector and selector not in format_candidates:
            format_candidates.append(selector)

    stream_url = getattr(self, "_reconnect_stream_url", self.url)
    LOG.info(
        "Reconnect attempt %d for %s (same stream ID %s)",
        attempt,
        self.channel,
        getattr(self, "_reconnect_stream_id", "unknown"),
    )

    last_error = None
    for index, selector in enumerate(format_candidates):
        for path in _candidate_paths(temp_base):
            try:
                if os.path.exists(path):
                    os.remove(path)
            except OSError:
                pass

        params = copy(base_params)
        params["format"] = selector
        if index > 0:
            LOG.warning(
                "No reconnect segment with format %s; retrying same stream with fallback format %s",
                format_candidates[index - 1],
                selector,
            )

        live_appender = _LiveTsAppender(temp_base, main_path, attempt)
        live_appender.start()

        dl = YoutubeDL(params)
        dl.add_progress_hook(self._ytdlProgress)
        had_error = False
        interrupted = False
        try:
            result = dl.download([stream_url])
            if result not in (None, 0):
                had_error = True
                last_error = f"yt-dlp returned code {result}"
        except KeyboardInterrupt:
            interrupted = True
        except BaseException as exc:
            had_error = True
            last_error = str(exc)
            LOG.warning(
                "Reconnect download ended with an error using format %s: %s",
                selector,
                exc,
            )
        finally:
            try:
                dl.close()
            except Exception:
                pass
            live_copied = live_appender.stop_and_drain()

        if live_copied > 0:
            live_appender.cleanup_sources()
            cleanup_temp_dir()
            LOG.info(
                "Reconnect data was live-appended into the original recording (%d bytes, format %s)",
                live_copied,
                selector,
            )
            self._reconnect_format = selector
            if interrupted:
                raise KeyboardInterrupt()
            return not had_error or live_copied > 0

        if interrupted:
            # No live-tail bytes were observed (for example a non-TS fallback).
            # Preserve any completed scratch output before honoring the stop.
            candidate = _find_output(temp_base)
            if candidate is not None:
                prepared = _ensure_mpegts_segment(candidate)
                if prepared is not None:
                    try:
                        _append_file(prepared, main_path)
                    except BaseException as exc:
                        LOG.warning("Could not preserve reconnect output during stop: %s", exc)
            cleanup_temp_dir()
            raise KeyboardInterrupt()

        # If the reconnect output was not a live-tail-safe MPEG-TS file (for
        # example an MP4 fallback), retain the proven v0.4.14 behavior: wait for
        # the attempt to end, remux if required, then append exactly once.
        candidate = _find_output(temp_base)
        if candidate is not None:
            prepared = _ensure_mpegts_segment(candidate)
            if prepared is None:
                return False
            try:
                appended = _append_file(prepared, main_path)
                cleanup_temp_dir()
                LOG.info(
                    "Appended completed reconnect segment to original recording (%d bytes, format %s)",
                    appended,
                    selector,
                )
                self._reconnect_format = selector
                return not had_error or appended > 0
            except BaseException as exc:
                LOG.error("Could not append reconnect segment: %s", exc)
                return False

        LOG.debug("Reconnect selector %s produced no segment file", selector)

    if last_error:
        LOG.warning("Reconnect attempt produced no segment file after all format fallbacks: %s", last_error)
    else:
        LOG.debug("Reconnect attempt produced no segment file after all format fallbacks")
    return False



def _install_pytchat_fresh_client_fix() -> None:
    """Make pytchat 0.5.5 compatible with current HTTPX AsyncClient.

    There are two separate issues in pytchat's LiveChatAsync implementation:

    1. ``client=httpx.AsyncClient(...)`` is a constructor default, so Python
       creates that client only once and may share it between chat recorders.
    2. More importantly, ``_startlisten`` performs a request with
       ``self._client`` *before* ``_listen`` later executes
       ``async with self._client``. Current HTTPX marks a client OPENED as soon
       as it sends its first request, so entering that same client as a context
       manager afterwards raises:

           RuntimeError: Cannot open a client instance more than once.

    This compatibility subclass fixes both: every recorder gets its own client,
    and the initial channel-id lookup uses a short-lived setup client so the
    recorder client remains unopened until pytchat's original ``_listen``
    enters it. ``_check_pause`` is also overridden to avoid nested context
    manager entry if a chat recorder is ever paused/resumed.
    """
    global _PYTCHAT_CLIENT_PATCHED
    if _PYTCHAT_CLIENT_PATCHED:
        return

    try:
        import httpx
        import pytchat
        from pytchat import util as pytchat_util
        from pytchat.paramgen import liveparam as pytchat_liveparam
    except ImportError as exc:
        LOG.debug("YouTube chat client compatibility patch not installed: %s", exc)
        return

    original = getattr(pytchat, "LiveChatAsync", None)
    if original is None:
        LOG.debug("pytchat.LiveChatAsync is unavailable; YouTube chat patch skipped")
        return
    if getattr(original, "_ytdvr_httpx_lifecycle_fix", False):
        _PYTCHAT_CLIENT_PATCHED = True
        return

    class CompatibleLiveChatAsync(original):
        _ytdvr_httpx_lifecycle_fix = True

        def __init__(self, *args, **kwargs):
            # pytchat 0.5.5 positional order is:
            # video_id, seektime, processor, buffer, client, ...
            # Only inject our client when one was not explicitly supplied.
            if len(args) < 5 and ("client" not in kwargs or kwargs.get("client") is None):
                kwargs["client"] = httpx.AsyncClient(http2=True)
            super().__init__(*args, **kwargs)

        async def _startlisten(self):
            # IMPORTANT: Do not touch self._client here. pytchat's original
            # _listen() later enters it with ``async with self._client``.
            # A request here would already mark it OPENED in current HTTPX.
            if not self.continuation:
                async with httpx.AsyncClient(http2=True) as setup_client:
                    channel_id = await pytchat_util.get_channelid_async(
                        setup_client, self._video_id
                    )
                self.continuation = pytchat_liveparam.getparam(
                    self._video_id, channel_id, past_sec=3
                )
            await self._listen(self.continuation)

        async def _check_pause(self, continuation):
            # The upstream implementation uses ``async with self._client``
            # again while _listen already owns that context. Use the already
            # open client directly instead.
            if self._pauser.empty():
                await self._pauser.get()
                self._pauser.put_nowait(None)
                if not self._is_replay:
                    channel_id = await pytchat_util.get_channelid_async(
                        self._client, self._video_id
                    )
                    continuation = pytchat_liveparam.getparam(
                        self._video_id, channel_id, past_sec=3
                    )
            return continuation

    CompatibleLiveChatAsync.__name__ = getattr(original, "__name__", "LiveChatAsync")
    CompatibleLiveChatAsync.__qualname__ = getattr(original, "__qualname__", "LiveChatAsync")
    CompatibleLiveChatAsync.__module__ = getattr(original, "__module__", "pytchat")
    pytchat.LiveChatAsync = CompatibleLiveChatAsync
    _PYTCHAT_CLIENT_PATCHED = True
    LOG.info(
        "Loaded YouTube chat fix: fresh HTTPX client + corrected AsyncClient lifecycle"
    )


def _chat_jsonl_path(txt_filename: str) -> str:
    """Return the sidecar JSONL path for an upstream .txt chat path."""
    stem, _ext = os.path.splitext(txt_filename)
    return stem + ".chat.jsonl"


def _safe_chat_value(value):
    """Convert a pytchat field to a JSON-safe scalar without raising."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def _parse_chat_time(value: object) -> datetime.datetime:
    try:
        parsed = dateparser.parse(str(value))
        if parsed is not None:
            return parsed
    except Exception:
        pass
    return datetime.datetime.now().astimezone()


def _chat_offset_seconds(message_time: datetime.datetime, start_time: datetime.datetime) -> float:
    """Calculate a stable offset even if one datetime has timezone info."""
    try:
        msg = message_time
        start = start_time
        if msg.tzinfo is None and start.tzinfo is not None:
            msg = msg.replace(tzinfo=start.tzinfo)
        elif msg.tzinfo is not None and start.tzinfo is None:
            start = start.replace(tzinfo=msg.tzinfo)
        return max(0.0, (msg - start).total_seconds())
    except Exception:
        return 0.0


class DualYoutubeChatRecorder(channel_mod.ChatRecorder):
    """Record YouTube live chat to both upstream TXT and JSONL sidecars.

    The recorder is created once for a RecordingInfo session. Video reconnects
    therefore keep writing to the exact same chat files instead of creating a
    new sidecar for every reconnect attempt.
    """

    def __init__(self, loop, info: dict, filename: str):
        import pytchat

        self.running = True
        self.conn = None
        self.video_id = str((info or {}).get("id") or "")
        self.txt_filename = filename
        self.jsonl_filename = _chat_jsonl_path(filename)
        self.start_time = datetime.datetime.now().astimezone()
        self._file_lock = threading.Lock()

        parent = os.path.dirname(filename)
        if parent:
            os.makedirs(parent, exist_ok=True)

        # Append mode is deliberate: if the same RecordingInfo survives a
        # reconnect or the recorder is re-created for the same path, existing
        # messages are preserved instead of being truncated.
        self.txt_file = open(filename, "a", encoding="utf-8", buffering=1)
        self.jsonl_file = open(self.jsonl_filename, "a", encoding="utf-8", buffering=1)

        LOG.info(
            "Chat recording files prepared for %s: TXT=%s JSONL=%s",
            self.video_id or "unknown",
            self.txt_filename,
            self.jsonl_filename,
        )

        self._start_future = asyncio.run_coroutine_threadsafe(self._start(pytchat), loop)
        self._start_future.add_done_callback(self._start_done)

    async def _start(self, pytchat_module):
        async def cb(chatdata):
            return await self.callback(chatdata)

        if not self.video_id:
            raise RuntimeError("YouTube chat could not start because the video ID is missing")

        # LiveChatAsync has already been replaced by the HTTPX lifecycle-safe
        # subclass in _install_pytchat_fresh_client_fix().
        self.conn = pytchat_module.LiveChatAsync(
            self.video_id,
            callback=cb,
            interruptable=False,
            logger=LOG,
        )
        LOG.info(
            "Chat recording started for YouTube video %s (TXT + JSONL)",
            self.video_id,
        )

    def _start_done(self, future) -> None:
        if future.cancelled():
            return
        try:
            exc = future.exception()
        except BaseException as callback_exc:
            LOG.error("Chat recording failed while checking startup status: %s", callback_exc)
            return
        if exc is not None:
            LOG.error(
                "Chat recording FAILED for YouTube video %s: %s",
                self.video_id or "unknown",
                exc,
                exc_info=(type(exc), exc, exc.__traceback__),
            )

    async def callback(self, chatdata):
        if not self.running:
            return
        try:
            async for item in chatdata.async_items():
                if not self.running:
                    return

                message_time = _parse_chat_time(getattr(item, "datetime", None))
                offset = _chat_offset_seconds(message_time, self.start_time)
                author = getattr(item, "author", None)
                author_name = str(getattr(author, "name", "") or "")
                message = str(getattr(item, "message", "") or "")

                txt_line = "[%s][%d] %s: %s\n" % (
                    message_time.isoformat(sep=" ", timespec="seconds"),
                    int(offset),
                    author_name,
                    message,
                )

                json_obj = {
                    "timestamp": message_time.isoformat(timespec="seconds"),
                    "timestamp_ms": _safe_chat_value(getattr(item, "timestamp", None)),
                    "offset_seconds": round(offset, 3),
                    "video_id": self.video_id,
                    "id": _safe_chat_value(getattr(item, "id", None)),
                    "type": _safe_chat_value(getattr(item, "type", None)),
                    "message": message,
                    "author": {
                        "name": author_name,
                        "channel_id": _safe_chat_value(getattr(author, "channelId", None)),
                        "channel_url": _safe_chat_value(getattr(author, "channelUrl", None)),
                        "image_url": _safe_chat_value(getattr(author, "imageUrl", None)),
                        "badge_url": _safe_chat_value(getattr(author, "badgeUrl", None)),
                        "is_verified": bool(getattr(author, "isVerified", False)),
                        "is_owner": bool(getattr(author, "isChatOwner", False)),
                        "is_sponsor": bool(getattr(author, "isChatSponsor", False)),
                        "is_moderator": bool(getattr(author, "isChatModerator", False)),
                    },
                    "amount_value": _safe_chat_value(getattr(item, "amountValue", None)),
                    "amount_string": _safe_chat_value(getattr(item, "amountString", None)),
                    "currency": _safe_chat_value(getattr(item, "currency", None)),
                }

                with self._file_lock:
                    if not self.running:
                        return
                    self.txt_file.write(txt_line)
                    self.jsonl_file.write(
                        json.dumps(json_obj, ensure_ascii=False, separators=(",", ":")) + "\n"
                    )
                    self.txt_file.flush()
                    self.jsonl_file.flush()
        except Exception as exc:
            LOG.error(
                "Chat recording callback FAILED for YouTube video %s: %s",
                self.video_id or "unknown",
                exc,
                exc_info=(type(exc), exc, exc.__traceback__),
            )

    def stop(self):
        if not self.running:
            return
        self.running = False
        try:
            if self.conn is not None:
                self.conn.terminate()
        except BaseException as exc:
            LOG.debug("Ignoring error while stopping YouTube chat connection: %s", exc)

        with self._file_lock:
            for handle in (getattr(self, "txt_file", None), getattr(self, "jsonl_file", None)):
                try:
                    if handle is not None and not handle.closed:
                        handle.flush()
                        handle.close()
                except Exception:
                    pass

        LOG.info(
            "Chat recording stopped for YouTube video %s (TXT + JSONL saved)",
            self.video_id or "unknown",
        )


def _create_chat_recorder(loop, platform: str, url: str, filename: str, info: Optional[dict]):
    """Create a recorder and report failures instead of silently returning None."""
    try:
        if _is_youtube_platform(platform):
            recorder = DualYoutubeChatRecorder(loop, info or {}, filename)
        else:
            recorder = channel_mod.get_chat_recorder(loop, platform, url, filename, info)

        if recorder is None:
            LOG.error(
                "Chat recording FAILED to start for platform %s: recorder is unavailable",
                platform,
            )
        return recorder
    except BaseException as exc:
        LOG.error(
            "Chat recording FAILED to start for platform %s: %s",
            platform,
            exc,
            exc_info=(type(exc), exc, exc.__traceback__),
        )
        return None



def _ffmpeg_executable() -> str:
    """Return the FFmpeg executable used by yt-dvr.

    v0.4.30 uses the same configured/bundled FFmpeg for chat post-processing as
    the recorder uses for remuxing.
    """
    explicit = getattr(config, "ffmpegPath", None)
    if explicit:
        return str(explicit)
    if hasattr(sys, "_MEIPASS"):
        bundled = os.path.join(str(sys._MEIPASS), "ffmpeg.exe")  # type: ignore[attr-defined]
        if os.path.isfile(bundled):
            return bundled
    found = shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
    if found:
        return found
    return "ffmpeg"


def _chat_derived_relpaths(filename: str) -> tuple[str, str]:
    """Return deterministic soft-track and burned-overlay output paths."""
    stem, ext = os.path.splitext(filename)
    lower = ext.lower()
    soft_ext = lower if lower in {".mp4", ".m4v", ".mov", ".mkv"} else ".mkv"
    return stem + ".chat-track" + soft_ext, stem + ".chat-overlay.mp4"


def _chat_abs_path(path: str) -> str:
    """Resolve a recording/chat path against saveDir before FFmpeg changes cwd.

    Rich/ASS overlay rendering intentionally runs FFmpeg from a temporary work
    directory so its concat/ASS sidecars can use simple filenames.  If saveDir
    is configured as a relative path such as ``files`` (the yt-dvr default),
    passing ``files/channel/video.mp4`` to that FFmpeg process makes it look
    below the temporary directory and fail with ``No such file or directory``.
    Always hand post-processing absolute source/output paths instead.
    """
    if os.path.isabs(path):
        return os.path.normpath(path)
    return os.path.abspath(os.path.join(config.saveDir, path))


def _effective_channel_params(self: RecordingInfo) -> dict[str, Any]:
    """Return the latest channel ytdlParams for final post-processing.

    Earlier builds snapshotted ytdlParams when the recording started.  That
    meant enabling the enhanced burned-in chat option while a stream was
    already running had no effect on that recording.  Prefer the channel's
    current settings at finalization time, while retaining the recording
    snapshot as a fallback if the channel was removed from the config.
    """
    channels = getattr(config, "channels", {})
    current = channels.get(self.channel) if isinstance(channels, dict) else None
    if current is not None:
        latest = getattr(current, "ytdlParams", None)
        return deepcopy(latest or {}) if isinstance(latest, dict) or latest is None else {}
    snapshot = getattr(self, "_ytdvr_channel_params", None)
    return deepcopy(snapshot or {}) if isinstance(snapshot, dict) or snapshot is None else {}


def _chat_postprocess_enabled(self: RecordingInfo) -> bool:
    opts = _special_ytdvr_options(_effective_channel_params(self))
    return bool(opts["chat_embed_track"] or opts["chat_burn_overlay"])


def _load_chat_messages(jsonl_path: str) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    try:
        with open(jsonl_path, "r", encoding="utf-8-sig") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                try:
                    offset = max(0.0, float(obj.get("offset_seconds") or 0.0))
                except (TypeError, ValueError):
                    continue
                message = str(obj.get("message") or "").strip()
                if not message:
                    continue
                author_obj = obj.get("author")
                author = ""
                if isinstance(author_obj, dict):
                    author = str(author_obj.get("name") or "").strip()
                amount = str(obj.get("amount_string") or "").strip()
                author_obj = author_obj if isinstance(author_obj, dict) else {}
                messages.append({
                    "offset": offset,
                    "author": author or "YouTube user",
                    "message": message,
                    "amount": amount,
                    "amount_value": obj.get("amount_value"),
                    "currency": str(obj.get("currency") or ""),
                    "id": str(obj.get("id") or ""),
                    "type": str(obj.get("type") or ""),
                    "image_url": str(author_obj.get("image_url") or ""),
                    "badge_url": str(author_obj.get("badge_url") or ""),
                    "is_verified": bool(author_obj.get("is_verified")),
                    "is_owner": bool(author_obj.get("is_owner")),
                    "is_sponsor": bool(author_obj.get("is_sponsor")),
                    "is_moderator": bool(author_obj.get("is_moderator")),
                })
    except FileNotFoundError:
        return []
    except OSError as exc:
        LOG.warning("Could not read JSONL chat file %s: %s", jsonl_path, exc)
        return []

    messages.sort(key=lambda item: float(item["offset"]))
    # Avoid duplicate message IDs if a chat callback was ever replayed.
    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in messages:
        msg_id = str(item.get("id") or "")
        if msg_id and msg_id in seen:
            continue
        if msg_id:
            seen.add(msg_id)
        deduped.append(item)
    return deduped


def _subtitle_time(seconds: float, *, ass: bool = False) -> str:
    seconds = max(0.0, float(seconds))
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    remain = seconds % 60
    if ass:
        # ASS uses centiseconds and a one-digit-or-more hour field.
        whole = int(remain)
        centis = int(round((remain - whole) * 100))
        if centis >= 100:
            whole += 1
            centis -= 100
        return f"{hours}:{minutes:02d}:{whole:02d}.{centis:02d}"
    millis = int(round((remain - int(remain)) * 1000))
    whole = int(remain)
    if millis >= 1000:
        whole += 1
        millis -= 1000
    return f"{hours:02d}:{minutes:02d}:{whole:02d},{millis:03d}"


def _plain_chat_text(item: dict[str, Any]) -> str:
    author = str(item.get("author") or "YouTube user")
    message = str(item.get("message") or "")
    amount = str(item.get("amount") or "")
    prefix = f"[{amount}] " if amount else ""
    return f"{prefix}{author}: {message}".strip()


def _write_chat_srt(messages: list[dict[str, Any]], path: str, duration: float) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="\n") as handle:
        for index, item in enumerate(messages, 1):
            start = float(item["offset"])
            end = start + duration
            text = _plain_chat_text(item).replace("\r", " ")
            handle.write(f"{index}\n{_subtitle_time(start)} --> {_subtitle_time(end)}\n{text}\n\n")


def _ass_escape(value: str) -> str:
    # Escape ASS override delimiters and preserve user line breaks.
    value = value.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")
    value = value.replace("\r\n", "\n").replace("\r", "\n").replace("\n", r"\N")
    return value


def _ass_chat_line(item: dict[str, Any]) -> str:
    author = _ass_escape(str(item.get("author") or "YouTube user"))
    message = _ass_escape(str(item.get("message") or ""))
    amount = _ass_escape(str(item.get("amount") or ""))
    if amount:
        return rf"{{\b1}}[{amount}] {author}{{\b0}}: {message}"
    return rf"{{\b1}}{author}{{\b0}}: {message}"


def _write_chat_ass(
    messages: list[dict[str, Any]],
    path: str,
    *,
    duration: float,
    max_lines: int,
    play_res_x: int = 1920,
    play_res_y: int = 1080,
    panel_left: int = 1120,
) -> None:
    """Create a rolling chat block positioned in a dedicated right-side area."""
    play_res_x = max(320, int(play_res_x))
    play_res_y = max(240, int(play_res_y))
    panel_left = max(0, min(play_res_x - 120, int(panel_left)))
    font_size = max(16, int(round(30 * play_res_y / 1080.0)))
    margin_right = max(18, int(round(45 * play_res_y / 1080.0)))
    margin_top = max(36, int(round(80 * play_res_y / 1080.0)))
    header = (
        "[Script Info]\nScriptType: v4.00+\n"
        f"PlayResX: {play_res_x}\nPlayResY: {play_res_y}\n"
        "WrapStyle: 2\nScaledBorderAndShadow: yes\n\n[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Chat,Segoe UI,{font_size},&H00FFFFFF,&H00FFFFFF,&H80000000,&H80000000,0,0,0,0,100,100,0,0,3,1,0,9,{panel_left},{margin_right},{margin_top},1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    with open(path, "w", encoding="utf-8-sig", newline="\n") as handle:
        handle.write(header)
        for i, item in enumerate(messages):
            start = float(item["offset"])
            next_start = float(messages[i + 1]["offset"]) if i + 1 < len(messages) else start + duration
            end = min(start + duration, max(start + 0.05, next_start))
            recent = messages[max(0, i - max_lines + 1): i + 1]
            panel = r"\N".join(_ass_chat_line(x) for x in recent)
            text = r"{\an9\q2}" + panel
            handle.write(
                f"Dialogue: 0,{_subtitle_time(start, ass=True)},{_subtitle_time(end, ass=True)},Chat,,0,0,0,,{text}\n"
            )

def _format_ffmpeg_clock(seconds: float) -> str:
    seconds = max(0.0, float(seconds or 0.0))
    whole = int(seconds)
    hours, remain = divmod(whole, 3600)
    minutes, secs = divmod(remain, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def _format_output_size(value: int) -> str:
    size = max(0, int(value or 0))
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    amount = float(size)
    for unit in units:
        if amount < 1024.0 or unit == units[-1]:
            if unit == "B":
                return f"{int(amount)} {unit}"
            return f"{amount:.1f} {unit}"
        amount /= 1024.0
    return f"{size} B"


def _parse_ffmpeg_progress_time(value: str) -> float:
    value = str(value or "").strip()
    match = re.match(r"^(\d+):(\d{2}):(\d{2}(?:\.\d+)?)$", value)
    if not match:
        return 0.0
    try:
        return int(match.group(1)) * 3600.0 + int(match.group(2)) * 60.0 + float(match.group(3))
    except (TypeError, ValueError):
        return 0.0


def _run_ffmpeg(
    args: list[str],
    *,
    cwd: Optional[str] = None,
    progress_label: Optional[str] = None,
    total_duration: float = 0.0,
) -> tuple[bool, str]:
    """Run FFmpeg, optionally reporting live encoding progress.

    v0.4.30 uses FFmpeg's machine-readable ``-progress`` stream for long
    burned-in chat renders.  This avoids the apparent hang from older builds,
    which buffered all FFmpeg output until the entire re-encode had finished.
    """
    show_progress = bool(progress_label)
    cmd = [_ffmpeg_executable(), "-hide_banner", "-y"]
    if show_progress:
        cmd += ["-progress", "pipe:1", "-nostats"]
    cmd += args

    if not show_progress:
        try:
            proc = subprocess.run(
                cmd,
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                check=False,
            )
        except OSError as exc:
            return False, str(exc)
        output = proc.stdout or ""
        return proc.returncode == 0, output

    try:
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        # Keep long overlay encodes responsive/cooler on Windows by scheduling
        # FFmpeg below normal priority.  The explicit codec thread cap does the
        # main CPU limiting; priority is an additional safety net.
        if os.name == "nt":
            creationflags |= getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)
        proc = subprocess.Popen(
            cmd,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            creationflags=creationflags,
        )
    except OSError as exc:
        return False, str(exc)

    output_lines: list[str] = []
    progress: dict[str, str] = {}
    last_report = 0.0
    last_percent = -1.0
    started = time.monotonic()
    duration = max(0.0, float(total_duration or 0.0))
    _chat_progress("%s", progress_label)

    assert proc.stdout is not None
    for raw_line in proc.stdout:
        line = raw_line.rstrip("\r\n")
        output_lines.append(line)
        if len(output_lines) > 1200:
            del output_lines[:200]

        if "=" in line:
            key, value = line.split("=", 1)
            key = key.strip()
            if key in {
                "frame", "fps", "stream_0_0_q", "bitrate", "total_size",
                "out_time_us", "out_time_ms", "out_time", "dup_frames",
                "drop_frames", "speed", "progress",
            }:
                progress[key] = value.strip()

        if line.startswith("progress="):
            now = time.monotonic()
            current = _parse_ffmpeg_progress_time(progress.get("out_time", ""))
            if current <= 0.0:
                # Recent FFmpeg exposes out_time_us; some older builds expose
                # out_time_ms but historically store microseconds in it too.
                raw_us = progress.get("out_time_us") or progress.get("out_time_ms") or "0"
                try:
                    current = max(0.0, float(raw_us) / 1_000_000.0)
                except ValueError:
                    current = 0.0
            percent = (current / duration * 100.0) if duration > 0.0 else -1.0
            done = progress.get("progress") == "end"
            due = done or (now - last_report >= 5.0)
            if percent >= 0.0 and last_percent >= 0.0 and percent - last_percent >= 1.0:
                due = True
            if due:
                speed = progress.get("speed") or "?"
                total_size = 0
                try:
                    total_size = int(progress.get("total_size") or 0)
                except ValueError:
                    total_size = 0
                elapsed = max(0.0, now - started)
                if duration > 0.0:
                    pct_text = f"{min(100.0, max(0.0, percent)):.1f}%"
                    _chat_progress(
                        "%s: %s / %s | %s | speed %s | output %s | elapsed %s",
                        progress_label,
                        _format_ffmpeg_clock(current),
                        _format_ffmpeg_clock(duration),
                        pct_text,
                        speed,
                        _format_output_size(total_size),
                        _format_ffmpeg_clock(elapsed),
                    )
                    last_percent = percent
                else:
                    _chat_progress(
                        "%s: %s | speed %s | output %s | elapsed %s",
                        progress_label,
                        _format_ffmpeg_clock(current),
                        speed,
                        _format_output_size(total_size),
                        _format_ffmpeg_clock(elapsed),
                    )
                last_report = now

    returncode = proc.wait()
    output = "\n".join(output_lines)
    return returncode == 0, output


def _ffmpeg_has_ass_filter() -> bool:
    try:
        proc = subprocess.run(
            [_ffmpeg_executable(), "-hide_banner", "-filters"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
        if proc.returncode != 0:
            return False
        return bool(re.search(r"(?m)^\s*[TSC\.]{3}\s+ass\s", proc.stdout or "")) or " ass " in (proc.stdout or "")
    except OSError:
        return False


def _temporary_output_path(final_path: str) -> str:
    stem, ext = os.path.splitext(final_path)
    return stem + ".tmp" + ext


def _embed_chat_track(source: str, srt_path: str, output: str) -> bool:
    ext = os.path.splitext(output)[1].lower()
    subtitle_codec = "mov_text" if ext in {".mp4", ".m4v", ".mov"} else "srt"
    temp_output = _temporary_output_path(output)
    try:
        os.remove(temp_output)
    except FileNotFoundError:
        pass
    args = [
        "-i", source,
        "-i", srt_path,
        "-map", "0:v?",
        "-map", "0:a?",
        "-map", "1:0",
        "-map_metadata", "0",
        "-c:v", "copy",
        "-c:a", "copy",
        "-c:s", subtitle_codec,
        "-metadata:s:s:0", "title=Live Chat",
        "-metadata:s:s:0", "language=und",
        "-disposition:s:0", "0",
    ]
    if ext in {".mp4", ".m4v", ".mov"}:
        args.extend(["-movflags", "+faststart"])
    args.append(temp_output)
    ok, output_text = _run_ffmpeg(args)
    if not ok:
        LOG.error("Could not embed chat subtitle track: %s", output_text[-4000:])
        try:
            os.remove(temp_output)
        except FileNotFoundError:
            pass
        return False
    os.replace(temp_output, output)
    return True



def _probe_video_info(source: str) -> tuple[int, int, float]:
    """Return (width, height, duration_seconds) using the configured FFmpeg."""
    try:
        proc = subprocess.run(
            [_ffmpeg_executable(), "-hide_banner", "-i", source],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
        text = proc.stdout or ""
    except OSError:
        return 1920, 1080, 0.0

    width, height = 1920, 1080
    video_match = re.search(r"Video:.*?\b(\d{2,5})x(\d{2,5})\b", text, re.S)
    if video_match:
        try:
            width, height = int(video_match.group(1)), int(video_match.group(2))
        except ValueError:
            pass
    duration = 0.0
    duration_match = re.search(r"Duration:\s*(\d+):(\d{2}):(\d{2}(?:\.\d+)?)", text)
    if duration_match:
        try:
            duration = int(duration_match.group(1)) * 3600 + int(duration_match.group(2)) * 60 + float(duration_match.group(3))
        except ValueError:
            duration = 0.0
    return width, height, duration


def _pil_font(size: int, bold: bool = False):
    from PIL import ImageFont

    candidates: list[str] = []
    windir = os.environ.get("WINDIR") or os.environ.get("SystemRoot")
    if windir:
        fonts = os.path.join(windir, "Fonts")
        candidates.extend([
            os.path.join(fonts, "segoeuib.ttf" if bold else "segoeui.ttf"),
            os.path.join(fonts, "arialbd.ttf" if bold else "arial.ttf"),
        ])
    candidates.extend([
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ])
    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            try:
                return ImageFont.truetype(candidate, size=size)
            except OSError:
                pass
    return ImageFont.load_default()


def _avatar_placeholder(name: str, size: int, theme: str):
    from PIL import Image, ImageDraw

    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    digest = hashlib.sha1(name.encode("utf-8", errors="ignore")).digest()
    color = (70 + digest[0] % 120, 70 + digest[1] % 120, 70 + digest[2] % 120, 255)
    draw.ellipse((0, 0, size - 1, size - 1), fill=color)
    initial = (name.strip()[:1] or "?").upper()
    font = _pil_font(max(12, int(size * 0.46)), bold=True)
    box = draw.textbbox((0, 0), initial, font=font)
    x = (size - (box[2] - box[0])) / 2
    y = (size - (box[3] - box[1])) / 2 - box[1]
    draw.text((x, y), initial, font=font, fill=(255, 255, 255, 255))
    return image


def _load_avatar(url: str, name: str, size: int, cache_dir: str, theme: str, enabled: bool):
    from PIL import Image, ImageDraw

    if not enabled or not url:
        return _avatar_placeholder(name, size, theme)
    key = hashlib.sha1(url.encode("utf-8", errors="ignore")).hexdigest()
    cache_path = os.path.join(cache_dir, key + ".png")
    try:
        if os.path.isfile(cache_path):
            avatar = Image.open(cache_path).convert("RGBA")
        else:
            req = request.Request(url, headers={"User-Agent": "Mozilla/5.0 yt-dlp-dvr/0.4.30"})
            with request.urlopen(req, timeout=6) as response:
                data = response.read(2 * 1024 * 1024)
            avatar = Image.open(io.BytesIO(data)).convert("RGBA")
            avatar.thumbnail((size * 2, size * 2))
            os.makedirs(cache_dir, exist_ok=True)
            avatar.save(cache_path, "PNG")
        avatar = avatar.resize((size, size), Image.Resampling.LANCZOS)
        mask = Image.new("L", (size, size), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
        out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        out.paste(avatar, (0, 0), mask)
        return out
    except Exception:
        return _avatar_placeholder(name, size, theme)


def _wrap_pil_text(draw, text: str, font, max_width: int) -> list[str]:
    text = str(text or "").replace("\r", " ").replace("\n", " ").strip()
    if not text:
        return [""]
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = word if not current else current + " " + word
        if draw.textlength(candidate, font=font) <= max_width:
            current = candidate
            continue
        if current:
            lines.append(current)
            current = ""
        if draw.textlength(word, font=font) <= max_width:
            current = word
            continue
        # Split unusually long tokens without losing text.
        part = ""
        for char in word:
            candidate = part + char
            if part and draw.textlength(candidate, font=font) > max_width:
                lines.append(part)
                part = char
            else:
                part = candidate
        current = part
    if current:
        lines.append(current)
    return lines or [""]


def _superchat_fill(item: dict[str, Any], theme: str) -> Optional[tuple[int, int, int, int]]:
    if not str(item.get("amount") or "").strip():
        return None
    try:
        value = float(item.get("amount_value") or 0)
    except (TypeError, ValueError):
        value = 0.0
    # YouTube-inspired tiers; deliberately approximate so currencies without a
    # normalized value still get a recognizable highlighted card.
    if value >= 100:
        return (220, 50, 47, 242)
    if value >= 50:
        return (230, 81, 0, 242)
    if value >= 20:
        return (245, 124, 0, 242)
    if value >= 10:
        return (255, 179, 0, 242)
    if value >= 5:
        return (0, 184, 212, 242)
    return (21, 101, 192, 242)


def _render_chat_panel(
    items: list[dict[str, Any]],
    *,
    panel_width: int,
    panel_height: int,
    theme: str,
    avatars: bool,
    badges: bool,
    superchat: bool,
    avatar_cache: str,
):
    from PIL import Image, ImageDraw

    theme = "light" if theme == "light" else "dark"
    if theme == "light":
        bg = (255, 255, 255, 245)
        fg = (15, 15, 15, 255)
        muted = (96, 96, 96, 255)
        divider = (220, 220, 220, 255)
        row_bg = (255, 255, 255, 0)
    else:
        bg = (15, 15, 15, 238)
        fg = (245, 245, 245, 255)
        muted = (170, 170, 170, 255)
        divider = (70, 70, 70, 255)
        row_bg = (15, 15, 15, 0)

    image = Image.new("RGBA", (panel_width, panel_height), bg)
    draw = ImageDraw.Draw(image)
    scale = panel_height / 1080.0
    margin = max(10, int(18 * scale))
    header_h = max(48, int(66 * scale))
    avatar_size = max(28, int(40 * scale))
    name_font = _pil_font(max(14, int(18 * scale)), bold=True)
    body_font = _pil_font(max(14, int(18 * scale)), bold=False)
    small_font = _pil_font(max(11, int(14 * scale)), bold=True)
    header_font = _pil_font(max(16, int(20 * scale)), bold=True)

    draw.text((margin, max(8, int(17 * scale))), "Live chat replay", font=header_font, fill=fg)
    draw.line((0, header_h - 1, panel_width, header_h - 1), fill=divider, width=max(1, int(scale)))

    rendered: list[tuple[dict[str, Any], int, list[str], list[tuple[str, tuple[int,int,int,int], tuple[int,int,int,int]]]]] = []
    available_text = panel_width - margin * 3 - avatar_size
    for item in items:
        message_lines = _wrap_pil_text(draw, str(item.get("message") or ""), body_font, available_text)
        badge_parts: list[tuple[str, tuple[int,int,int,int], tuple[int,int,int,int]]] = []
        if badges:
            if item.get("is_owner"):
                badge_parts.append(("OWNER", (255,255,255,255), (204,0,0,255)))
            elif item.get("is_moderator"):
                badge_parts.append(("MOD", (255,255,255,255), (45,112,190,255)))
            if item.get("is_sponsor"):
                badge_parts.append(("MEMBER", (255,255,255,255), (36,135,73,255)))
            if item.get("is_verified"):
                badge_parts.append(("✓", fg, (100,100,100,110)))
        line_h = max(18, int(23 * scale))
        text_h = len(message_lines) * line_h
        top_h = max(avatar_size, max(20, int(25 * scale)) + text_h)
        amount_extra = max(0, int(28 * scale)) if superchat and item.get("amount") else 0
        row_h = max(avatar_size + int(12 * scale), top_h + amount_extra + int(14 * scale))
        rendered.append((item, row_h, message_lines, badge_parts))

    # Keep newest messages and fit by actual rendered height, not just count.
    fit: list[tuple[dict[str, Any], int, list[str], list[tuple[str, tuple[int,int,int,int], tuple[int,int,int,int]]]]] = []
    budget = panel_height - header_h - margin
    used = 0
    for row in reversed(rendered):
        if fit and used + row[1] > budget:
            break
        fit.append(row)
        used += row[1]
    fit.reverse()

    y = header_h + margin
    for item, row_h, lines, badge_parts in fit:
        row_top = y
        highlight = _superchat_fill(item, theme) if superchat else None
        if highlight:
            draw.rounded_rectangle((margin // 2, row_top - 3, panel_width - margin // 2, row_top + row_h - 4), radius=max(6, int(9 * scale)), fill=highlight)
        elif row_bg[3]:
            draw.rectangle((0, row_top, panel_width, row_top + row_h), fill=row_bg)

        author = str(item.get("author") or "YouTube user")
        avatar = _load_avatar(str(item.get("image_url") or ""), author, avatar_size, avatar_cache, theme, avatars)
        image.alpha_composite(avatar, (margin, row_top + 2))

        text_x = margin * 2 + avatar_size
        name_y = row_top + 1
        name_fill = (255,255,255,255) if highlight else fg
        draw.text((text_x, name_y), author, font=name_font, fill=name_fill)
        cursor_x = text_x + int(draw.textlength(author, font=name_font)) + max(5, int(7 * scale))
        for badge_text, badge_fg, badge_bg in badge_parts:
            bw = int(draw.textlength(badge_text, font=small_font)) + max(10, int(12 * scale))
            bh = max(18, int(20 * scale))
            if cursor_x + bw > panel_width - margin:
                break
            draw.rounded_rectangle((cursor_x, name_y + 1, cursor_x + bw, name_y + bh), radius=max(3, int(4 * scale)), fill=badge_bg)
            draw.text((cursor_x + max(4, int(6 * scale)), name_y + 2), badge_text, font=small_font, fill=badge_fg)
            cursor_x += bw + max(4, int(5 * scale))

        body_y = name_y + max(22, int(26 * scale))
        if highlight and item.get("amount"):
            amount = str(item.get("amount") or "")
            draw.text((text_x, body_y), amount, font=small_font, fill=(255,255,255,255))
            body_y += max(20, int(23 * scale))
        for line in lines:
            draw.text((text_x, body_y), line, font=body_font, fill=name_fill)
            body_y += max(18, int(23 * scale))
        y += row_h
    return image


def _write_chat_panel_timeline(
    messages: list[dict[str, Any]],
    *,
    workdir: str,
    panel_width: int,
    panel_height: int,
    duration: float,
    max_lines: int,
    theme: str,
    avatars: bool,
    badges: bool,
    superchat: bool,
) -> str:
    """Render one PNG whenever chat state changes and build an ffconcat timeline."""
    from PIL import Image

    frames_dir = os.path.join(workdir, "chat_frames")
    avatar_cache = os.path.join(workdir, "avatar_cache")
    os.makedirs(frames_dir, exist_ok=True)
    os.makedirs(avatar_cache, exist_ok=True)
    events: list[tuple[float, str]] = []
    total_messages = len(messages)
    _chat_progress("Preparing enhanced chat frames: 0/%d", total_messages)

    # Blank chat panel from t=0 until the first message.
    blank = _render_chat_panel([], panel_width=panel_width, panel_height=panel_height, theme=theme,
                               avatars=avatars, badges=badges, superchat=superchat, avatar_cache=avatar_cache)
    blank_path = os.path.join(frames_dir, "frame_000000.png")
    blank.save(blank_path, "PNG")
    events.append((0.0, blank_path))

    recent: list[dict[str, Any]] = []
    for index, item in enumerate(messages, 1):
        recent.append(item)
        recent = recent[-max_lines:]
        panel = _render_chat_panel(recent, panel_width=panel_width, panel_height=panel_height, theme=theme,
                                   avatars=avatars, badges=badges, superchat=superchat, avatar_cache=avatar_cache)
        path = os.path.join(frames_dir, f"frame_{index:06d}.png")
        panel.save(path, "PNG")
        events.append((max(0.0, float(item.get("offset") or 0.0)), path))
        # Report often enough to prove the program is alive without flooding CMD.
        step = max(1, total_messages // 20)
        if index == 1 or index == total_messages or index % step == 0:
            pct = (index / total_messages * 100.0) if total_messages else 100.0
            _chat_progress("Preparing enhanced chat frames: %d/%d | %.1f%%", index, total_messages, pct)

    _chat_progress("Enhanced chat frames ready; starting FFmpeg encoder...")

    # Collapse events sharing the same timestamp; only the newest state matters.
    collapsed: list[tuple[float, str]] = []
    for event in events:
        if collapsed and abs(collapsed[-1][0] - event[0]) < 0.001:
            collapsed[-1] = event
        else:
            collapsed.append(event)

    timeline = os.path.join(workdir, "chat.ffconcat")
    end_time = max(duration, collapsed[-1][0] + 1.0 if collapsed else 1.0)
    with open(timeline, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("ffconcat version 1.0\n")
        for i, (start, path) in enumerate(collapsed):
            next_start = collapsed[i + 1][0] if i + 1 < len(collapsed) else end_time
            frame_duration = max(0.04, next_start - start)
            rel = os.path.relpath(path, workdir).replace("\\", "/").replace("'", "'\\''")
            handle.write(f"file '{rel}'\n")
            handle.write(f"duration {frame_duration:.6f}\n")
        # concat demuxer needs the final file repeated for its duration to be honored.
        if collapsed:
            rel = os.path.relpath(collapsed[-1][1], workdir).replace("\\", "/").replace("'", "'\\''")
            handle.write(f"file '{rel}'\n")
    return timeline


def _chat_encoder_profile(opts: dict[str, Any]) -> dict[str, Any]:
    """Return conservative encoder settings for chat post-processing.

    The default intentionally favors lower heat and responsiveness over maximum
    throughput.  Users can opt into faster/full-CPU modes from the channel UI.
    """
    name = str(opts.get("chat_cpu_profile") or "cool").strip().lower()
    profiles: dict[str, dict[str, Any]] = {
        "eco": {"label": "Eco / very low CPU", "threads": 1, "filter_threads": 1, "preset": "superfast", "crf": 24},
        "cool": {"label": "Cool / low CPU", "threads": 2, "filter_threads": 1, "preset": "veryfast", "crf": 23},
        "balanced": {"label": "Balanced", "threads": 4, "filter_threads": 2, "preset": "fast", "crf": 21},
        "full": {"label": "Full CPU", "threads": 0, "filter_threads": 0, "preset": "medium", "crf": 18},
    }
    return profiles.get(name, profiles["cool"])


def _scaled_chat_panel_width(video_w: int, video_h: int, opts: dict[str, Any]) -> int:
    scale = video_h / 1080.0 if video_h > 0 else 1.0
    width = max(240, min(max(240, video_w), int(int(opts.get("chat_overlay_width") or 520) * scale)))
    # yuv420p requires even dimensions on many encoders.
    return max(240, width - (width % 2))


def _burn_chat_overlay_rich(source: str, messages: list[dict[str, Any]], output: str, workdir: str, opts: dict[str, Any]) -> bool:
    """Create a YouTube-inspired replay panel BESIDE the video, not over it."""
    try:
        import PIL  # noqa: F401
    except Exception as exc:
        LOG.warning("Pillow is unavailable; falling back to the ASS chat side-panel: %s", exc)
        return False

    video_w, video_h, video_duration = _probe_video_info(source)
    panel_width = _scaled_chat_panel_width(video_w, video_h, opts)
    panel_height = max(240, video_h)
    output_w = video_w + panel_width
    profile = _chat_encoder_profile(opts)

    _chat_progress(
        "Enhanced chat side-panel layout: video %dx%d + chat %dx%d = %dx%d | CPU mode: %s",
        video_w, video_h, panel_width, panel_height, output_w, video_h, profile["label"],
    )

    # Remove stale/aborted temp output before the potentially lengthy rich-frame
    # preparation phase, so Explorer does not misleadingly show an old 0-byte
    # .tmp.mp4 while the new job is still preparing chat frames.
    temp_output = _temporary_output_path(output)
    try:
        os.remove(temp_output)
    except FileNotFoundError:
        pass

    timeline = _write_chat_panel_timeline(
        messages,
        workdir=workdir,
        panel_width=panel_width,
        panel_height=panel_height,
        duration=video_duration,
        max_lines=int(opts.get("chat_overlay_lines") or 8),
        theme=str(opts.get("chat_overlay_theme") or "dark"),
        avatars=bool(opts.get("chat_overlay_avatars", True)),
        badges=bool(opts.get("chat_overlay_badges", True)),
        superchat=bool(opts.get("chat_overlay_superchat", True)),
    )

    base = [
        "-i", source,
        "-f", "concat", "-safe", "0", "-i", os.path.basename(timeline),
    ]
    filter_threads = int(profile["filter_threads"])
    if filter_threads > 0:
        base += ["-filter_complex_threads", str(filter_threads)]
    # The chat panel is appended to the RIGHT of the complete original video.
    # No pixels from the source video are covered or cropped.
    base += [
        "-filter_complex", "[0:v]format=yuv420p[video];[1:v]format=yuv420p[chat];[video][chat]hstack=inputs=2:shortest=0[v]",
        "-map", "[v]", "-map", "0:a?", "-map_metadata", "0",
        "-c:a", "copy", "-movflags", "+faststart",
    ]

    threads = int(profile["threads"])
    x264 = [*base, "-c:v", "libx264", "-preset", str(profile["preset"]), "-crf", str(profile["crf"])]
    mpeg4 = [*base, "-c:v", "mpeg4", "-q:v", "4"]
    if threads > 0:
        x264 += ["-threads", str(threads)]
        mpeg4 += ["-threads", str(threads)]
    x264 += ["-pix_fmt", "yuv420p", temp_output]
    mpeg4 += ["-pix_fmt", "yuv420p", temp_output]
    attempts = [x264, mpeg4]

    last_output = ""
    for attempt_index, args in enumerate(attempts, 1):
        ok, text = _run_ffmpeg(
            args,
            cwd=workdir,
            progress_label="Enhanced chat side-panel rendering",
            total_duration=video_duration,
        )
        last_output = text
        if ok:
            os.replace(temp_output, output)
            if attempt_index > 1:
                LOG.warning("Rich chat side-panel used MPEG-4 encoder fallback because libx264 was unavailable")
            return True
        try:
            os.remove(temp_output)
        except FileNotFoundError:
            pass
    LOG.error("Could not create rich YouTube-style chat side-panel: %s", last_output[-4000:])
    return False

def _burn_chat_overlay(source: str, ass_path: str, output: str, workdir: str, opts: dict[str, Any]) -> bool:
    if not _ffmpeg_has_ass_filter():
        LOG.error(
            "Visible chat side-panel was requested, but this FFmpeg build does not provide the ass/libass filter. "
            "The normal recording and soft chat track are unaffected."
        )
        return False

    temp_output = _temporary_output_path(output)
    try:
        os.remove(temp_output)
    except FileNotFoundError:
        pass

    video_w, video_h, video_duration = _probe_video_info(source)
    panel_width = _scaled_chat_panel_width(video_w, video_h, opts)
    profile = _chat_encoder_profile(opts)
    theme = str(opts.get("chat_overlay_theme") or "dark").lower()
    pad_color = "white" if theme == "light" else "0x0f0f0f"
    filter_threads = int(profile["filter_threads"])

    base_args = ["-i", source]
    if filter_threads > 0:
        base_args += ["-filter_threads", str(filter_threads)]
    base_args += [
        "-vf", f"pad=iw+{panel_width}:ih:0:0:color={pad_color},ass=chat.ass",
        "-map", "0:v:0", "-map", "0:a?", "-map_metadata", "0",
        "-c:a", "copy", "-movflags", "+faststart",
    ]
    threads = int(profile["threads"])
    x264 = [*base_args, "-c:v", "libx264", "-preset", str(profile["preset"]), "-crf", str(profile["crf"])]
    mpeg4 = [*base_args, "-c:v", "mpeg4", "-q:v", "4"]
    if threads > 0:
        x264 += ["-threads", str(threads)]
        mpeg4 += ["-threads", str(threads)]
    x264 += ["-pix_fmt", "yuv420p", temp_output]
    mpeg4 += ["-pix_fmt", "yuv420p", temp_output]
    attempts = [x264, mpeg4]

    last_output = ""
    for attempt_index, args in enumerate(attempts, 1):
        ok, output_text = _run_ffmpeg(
            args,
            cwd=workdir,
            progress_label="Enhanced chat side-panel rendering (ASS fallback)",
            total_duration=video_duration,
        )
        last_output = output_text
        if ok:
            os.replace(temp_output, output)
            if attempt_index > 1:
                LOG.warning("Visible chat side-panel used MPEG-4 encoder fallback because libx264 was unavailable")
            return True
        try:
            os.remove(temp_output)
        except FileNotFoundError:
            pass

    LOG.error("Could not create visible chat side-panel video: %s", last_output[-4000:])
    return False

def _postprocess_chat_outputs(self: RecordingInfo) -> None:
    raw_params = _effective_channel_params(self)
    opts = _special_ytdvr_options(raw_params)
    if not (opts["chat_embed_track"] or opts["chat_burn_overlay"]):
        return
    if not getattr(self, "chat_filename", None):
        LOG.warning("Chat post-processing was requested, but Get chat was not enabled for %s", self.channel)
        return

    source = _chat_abs_path(self.filename)
    jsonl_rel = _chat_jsonl_path(cast(str, self.chat_filename))
    jsonl_path = _chat_abs_path(jsonl_rel)
    if not os.path.isfile(source):
        LOG.error("Chat post-processing skipped: final video file does not exist: %s", source)
        return

    messages = _load_chat_messages(jsonl_path)
    if not messages:
        LOG.info("Chat post-processing skipped for %s: no chat messages were recorded", self.title)
        return

    track_rel, overlay_rel = _chat_derived_relpaths(self.filename)
    track_path = _chat_abs_path(track_rel)
    overlay_path = _chat_abs_path(overlay_rel)
    os.makedirs(os.path.dirname(track_path), exist_ok=True)

    temp_root = _chat_abs_path(".yt-dvr-chat-postprocess")
    os.makedirs(temp_root, exist_ok=True)
    _chat_progress(
        "Chat post-processing started for %s (%d messages; soft-track=%s; visible-overlay=%s)",
        self.title,
        len(messages),
        bool(opts["chat_embed_track"]),
        bool(opts["chat_burn_overlay"]),
    )
    if opts["chat_burn_overlay"]:
        _chat_progress(
            "Enhanced side-by-side chat render is starting. The chat panel will be placed to the RIGHT of the video without covering it; final output: %s",
            overlay_path,
        )

    try:
        with tempfile.TemporaryDirectory(prefix=f"{self.timestamp}-", dir=temp_root) as workdir:
            srt_path = os.path.join(workdir, "chat.srt")
            ass_path = os.path.join(workdir, "chat.ass")

            if opts["chat_embed_track"]:
                _write_chat_srt(messages, srt_path, float(opts["chat_overlay_seconds"]))
                if _embed_chat_track(source, srt_path, track_path):
                    LOG.info("Embedded switchable live-chat track: %s", track_path)

            if opts["chat_burn_overlay"]:
                rich_ok = _burn_chat_overlay_rich(source, messages, overlay_path, workdir, opts)
                if not rich_ok:
                    video_w, video_h, _video_duration = _probe_video_info(source)
                    panel_width = _scaled_chat_panel_width(video_w, video_h, opts)
                    _write_chat_ass(
                        messages,
                        ass_path,
                        duration=float(opts["chat_overlay_seconds"]),
                        max_lines=int(opts["chat_overlay_lines"]),
                        play_res_x=video_w + panel_width,
                        play_res_y=video_h,
                        panel_left=video_w + max(12, int(panel_width * 0.04)),
                    )
                    rich_ok = _burn_chat_overlay(source, ass_path, overlay_path, workdir, opts)
                if rich_ok:
                    _chat_progress("Created enhanced YouTube-style side-by-side chat replay video: %s", overlay_path)
    except BaseException as exc:
        LOG.exception("Chat post-processing failed for %s: %s", self.title, exc)


def _start_chat_postprocess(self: RecordingInfo) -> None:
    if not _chat_postprocess_enabled(self):
        return
    thread = threading.Thread(
        target=_postprocess_chat_outputs,
        name=f"chat-postprocess-{self.timestamp}",
        args=(self,),
        # A long video re-encode should be allowed to finish during a normal
        # yt-dvr shutdown instead of disappearing silently.
        daemon=False,
    )
    self._chat_postprocess_thread = thread
    thread.start()
    LOG.info("Chat post-processing queued in background for %s", self.title)


async def _patched_delete(self: RecordingInfo):
    """Delete JSONL and derived chat-video outputs with the normal recording."""
    jsonl_rel = getattr(self, "_chat_jsonl_filename", None)
    if not jsonl_rel and getattr(self, "chat_filename", None):
        jsonl_rel = _chat_jsonl_path(cast(str, self.chat_filename))
    track_rel, overlay_rel = _chat_derived_relpaths(self.filename)

    if _ORIGINAL_RECORDING_DELETE is not None:
        await _ORIGINAL_RECORDING_DELETE(self)

    for rel in [jsonl_rel, track_rel, overlay_rel]:
        if not rel:
            continue
        try:
            os.remove(_chat_abs_path(rel))
        except FileNotFoundError:
            pass
        except OSError as exc:
            LOG.warning("Could not delete chat sidecar/output %s: %s", rel, exc)


def _patched_dump(self: RecordingInfo) -> dict:
    """Expose the JSONL sidecar in the API while retaining upstream fields."""
    if _ORIGINAL_RECORDING_DUMP is not None:
        data = _ORIGINAL_RECORDING_DUMP(self)
    else:
        data = {}
    chat_filename = getattr(self, "chat_filename", None)
    data["chat_jsonl_path"] = (
        "/files/" + _chat_jsonl_path(cast(str, chat_filename))
        if chat_filename is not None
        else None
    )
    track_rel, overlay_rel = _chat_derived_relpaths(self.filename)
    data["chat_track_path"] = (
        "/files/" + track_rel if os.path.isfile(_chat_abs_path(track_rel)) else None
    )
    data["chat_overlay_path"] = (
        "/files/" + overlay_rel if os.path.isfile(_chat_abs_path(overlay_rel)) else None
    )
    return data

def _send_ended_webhook(self: RecordingInfo) -> None:
    # Webhooks were added after yt-dvr 0.3.0; keep compatibility with both the
    # 0.3.0 release and newer source builds.
    webhook = getattr(config, "webhook", None)
    if webhook is None or not hasattr(self, "formatWebhook"):
        return
    try:
        with request.urlopen(
            request.Request(
                webhook.url,
                bytes(self.formatWebhook(webhook.endedFormat), "utf-8"),
                {
                    "Content-Type": webhook.contentType
                    if webhook.contentType is not None
                    else "application/json",
                    "User-Agent": "yt-dlp-dvr/0.4.30",
                },
                method="POST",
            )
        ):
            pass
    except URLError as exc:
        LOG.error("Exception raised while sending webhook: %s", str(exc))


def _finish_recording(self: RecordingInfo, loop) -> None:
    self.in_progress = False
    _send_ended_webhook(self)
    tsstate = getattr(self, "_tsstate", None)
    if tsstate is not None:
        tsstate.running = False

    # Stop/flush chat before post-processing reads JSONL.  DualYoutubeChatRecorder
    # is idempotent, so an explicit user stop may safely call stop() again later.
    if self._chatRecorder is not None:
        try:
            self._chatRecorder.stop()
        except BaseException as exc:
            LOG.warning("Could not stop/flush chat recorder before finalization: %s", exc)

    if not self._abort:
        if self.filename.endswith(".ts") and config.remuxRecordings:
            self.remux()
        loop.call_soon_threadsafe(self.update)
        _start_chat_postprocess(self)
    self._ytdlProcess = None


def _patched_progress(self: RecordingInfo, _status) -> None:
    # Keep _stop True so the reconnect loop can distinguish an intentional stop
    # from an accidental downloader exit.
    if self._stop:
        raise KeyboardInterrupt()


def _patched_ytdl_main(self: RecordingInfo, first_dl: YoutubeDL, loop) -> None:
    """Download, reconnect to the same YouTube video ID, then remux once."""
    try:
        first_dl.add_progress_hook(self._ytdlProgress)
        first_error = False
        try:
            result = first_dl.download([getattr(self, "_reconnect_stream_url", self.url)])
            if result not in (None, 0):
                first_error = True
        except KeyboardInterrupt:
            if not self._stop:
                raise
        except BaseException as exc:
            first_error = True
            LOG.warning("Initial live download ended with an error: %s", exc)
        finally:
            try:
                first_dl.close()
            except Exception:
                pass

        _normalize_first_output(self)

        if self._stop or self._abort:
            return

        if not getattr(self, "_reconnect_enabled", False):
            return

        # Whether yt-dlp reported success or failure, verify whether the SAME
        # video ID is still live. A clean downloader exit can still be caused by
        # a temporary manifest transition.
        deadline = time.monotonic() + OFFLINE_GRACE_SECONDS
        attempt = 0

        while not self._stop and not self._abort:
            status, info = _probe_same_stream(self)

            if status == "same_live":
                attempt += 1
                deadline = time.monotonic() + OFFLINE_GRACE_SECONDS
                LOG.warning(
                    "Downloader stopped but stream %s is still live; reconnecting in %d seconds",
                    getattr(self, "_reconnect_stream_id", "unknown"),
                    RECONNECT_DELAY_SECONDS,
                )
                time.sleep(RECONNECT_DELAY_SECONDS)
                if self._stop or self._abort:
                    break
                try:
                    _download_one_reconnect_segment(self, attempt)
                except KeyboardInterrupt:
                    break
                # After this attempt exits, probe again. Do not finalize yet.
                continue

            if status == "different":
                new_id = info.get("id") if isinstance(info, dict) else "unknown"
                LOG.info(
                    "Channel now points to a different livestream (%s); finishing old stream %s",
                    new_id,
                    getattr(self, "_reconnect_stream_id", "unknown"),
                )
                break

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                LOG.info(
                    "Stream %s stayed offline for %d seconds; finalizing recording",
                    getattr(self, "_reconnect_stream_id", "unknown"),
                    OFFLINE_GRACE_SECONDS,
                )
                break

            LOG.warning(
                "Stream temporarily unavailable; keeping the same recording open for %d more seconds",
                int(remaining),
            )
            time.sleep(min(RECONNECT_DELAY_SECONDS, max(1, remaining)))

    except KeyboardInterrupt:
        # Intentional stop/abort or Ctrl+C injected by yt-dvr.
        pass
    except BaseException as exc:
        LOG.exception("Reconnect recorder crashed: %s", exc)
    finally:
        _normalize_first_output(self)
        _finish_recording(self, loop)


def _patched_create_ytdl(
    cls,
    loop,
    dl: YoutubeDL,
    info: dict,
    getChat: bool,
    platform: str,
    channel: str,
    title: str,
):
    now = datetime.datetime.now()
    stamp = now.isoformat(sep=" ", timespec="seconds").replace(":", "-")
    filename = channel + "/" + channel_mod.pathvalidate.sanitize_filename(stamp + " - " + title + ".ts")
    chat_filename = (
        channel + "/" + channel_mod.pathvalidate.sanitize_filename(stamp + " - " + title + ".txt")
        if getChat
        else None
    )

    self = RecordingInfo(
        platform,
        channel,
        title,
        int(now.timestamp()),
        cast(str, info.get("original_url") or info.get("webpage_url") or ""),
        filename,
        chat_filename,
        True,
    )

    # _tsstate exists only in newer upstream builds; defining it here keeps
    # the finalizer compatible with yt-dvr 0.3.0.
    if not hasattr(self, "_tsstate"):
        self._tsstate = None

    self._reconnect_enabled = _is_youtube_platform(platform)
    self._reconnect_stream_id = str(info.get("id") or "")
    self._reconnect_stream_url = cast(
        str, info.get("webpage_url") or info.get("original_url") or self.url
    )
    self._reconnect_monitor_url = cast(
        str, getattr(dl, "_ytdvr_monitor_url", None) or info.get("original_url") or self.url
    )
    self._reconnect_base_params = copy(getattr(dl, "_ytdvr_base_params", {}) or {})
    self._ytdvr_channel_params = deepcopy(getattr(dl, "_ytdvr_channel_params", {}) or {})
    self._reconnect_format = dl.params.get("format") or DEFAULT_LIVE_FORMAT

    os.makedirs(os.path.join(config.saveDir, channel), exist_ok=True)
    dl.params["outtmpl"] = {"default": os.path.join(config.saveDir, self.filename)}
    dl.params["hls_use_mpegts"] = True
    # v0.4.30: keep the canonical recording visible/growing during the initial
    # live downloader too. Reconnect attempts still use private .part files and
    # are tailed safely into this same destination.
    dl.params["nopart"] = True
    dl.params["wait_for_video"] = (2, 5)

    external = dl.params.setdefault("external_downloader_args", {})
    if isinstance(external, dict):
        ffargs = external.setdefault("ffmpeg", [])
        if isinstance(ffargs, list):
            if "-rw_timeout" not in ffargs:
                ffargs.extend(["-rw_timeout", "15000000"])
            if "-seg_max_retry" not in ffargs:
                ffargs.extend(["-seg_max_retry", "20"])

    self._ytdlProcess = threading.Thread(
        target=self._ytdlMain,
        name=self.filename,
        args=[dl, loop],
    )
    self._ytdlProcess.start()

    if getChat and self.chat_filename is not None:
        chat_platform = "Youtube" if _is_youtube_platform(platform) else platform
        self._chat_jsonl_filename = _chat_jsonl_path(self.chat_filename)
        self._chatRecorder = _create_chat_recorder(
            loop,
            chat_platform,
            cast(str, info.get("original_url") or self._reconnect_stream_url),
            os.path.join(config.saveDir, self.chat_filename),
            info,
        )
        if self._chatRecorder is None:
            LOG.error(
                "Get chat is enabled for %s, but no chat recorder could be started",
                channel,
            )

    loop.call_soon_threadsafe(self._insert_into_db)
    LOG.info(
        "Starting recording process (TID %s, stream ID %s, reconnect=%s, grace=%ss)",
        self._ytdlProcess.native_id,
        self._reconnect_stream_id or "unknown",
        self._reconnect_enabled,
        OFFLINE_GRACE_SECONDS,
    )
    return self


def _patched_channel_check_live(self, loop, future) -> None:
    """yt-dvr liveness check with full PO profile + direct-watch fallback."""
    now = time.monotonic()
    backoff_until = float(getattr(self, "_ytdvr_bot_backoff_until", 0.0) or 0.0)
    if backoff_until > now:
        remaining = int(backoff_until - now)
        if remaining > 0:
            last_notice = float(getattr(self, "_ytdvr_bot_backoff_notice", 0.0) or 0.0)
            if now - last_notice >= 30:
                LOG.warning(
                    "YouTube authentication/bot challenge backoff active for %s (%ds remaining)",
                    self.url, remaining,
                )
                self._ytdvr_bot_backoff_notice = now
        loop.call_soon_threadsafe(future.set_result, (False, None))
        return

    is_youtube = _looks_like_youtube_url(self.url)
    params = _prepared_profile(self.ytdlParams, youtube=is_youtube, purpose="channel /live liveness")
    params["skip_download"] = True
    if LOG.level > logging.DEBUG:
        params.setdefault("noprogress", True)
        params.setdefault("quiet", True)

    # v0.4.30: expected YouTube monitoring states (offline channel or scheduled
    # live event not started yet) are presented as INFO. Real failures remain
    # ERROR and extractor control flow is unchanged.
    params["logger"] = _LivenessYTDLPLogger(self.url)
    dl = YoutubeDL(params)
    try:
        info = dl.extract_info(self.url, download=False)
    except utils.DownloadError as exc:
        # v0.4.30: yt-dlp may already have resolved /@handle/live to a concrete
        # video ID before a later player request receives the bot challenge.
        # The user's direct CLI test proved that extracting that exact watch URL
        # with cookies + Deno + mweb + bgutil succeeds, so retry it here with a
        # fresh YoutubeDL object and the same API profile.
        video_id = _youtube_video_id_from_error(exc) if is_youtube else None
        if is_youtube and _is_auth_or_bot_error(exc) and video_id:
            try:
                dl.close()
            except Exception:
                pass
            LOG.warning(
                "YouTube /live auth challenge resolved video ID %s; retrying direct watch URL with full PO profile",
                video_id,
            )
            try:
                direct_dl, direct_info = _extract_direct_watch(
                    self.ytdlParams, video_id, purpose="initial direct-watch PO liveness fallback"
                )
                if _info_is_live(direct_info):
                    self._ytdvr_bot_backoff_until = 0.0
                    self._ytdvr_last_resolved_watch_url = _direct_watch_url(video_id)
                    LOG.info("Direct-watch PO liveness fallback succeeded for %s", video_id)
                    loop.call_soon_threadsafe(future.set_result, (True, (direct_dl, direct_info)))
                    return
                try:
                    direct_dl.close()
                except Exception:
                    pass
                LOG.debug("Direct-watch fallback resolved %s but it is not live", video_id)
            except BaseException as direct_exc:
                LOG.warning("Direct-watch PO liveness fallback failed for %s: %s", video_id, direct_exc)

        if is_youtube and _is_auth_or_bot_error(exc):
            opts = _special_ytdvr_options(self.ytdlParams)
            backoff = int(opts["bot_backoff"])
            if backoff > 0:
                self._ytdvr_bot_backoff_until = time.monotonic() + backoff
                self._ytdvr_bot_backoff_notice = time.monotonic()
                LOG.warning(
                    "YouTube authentication/bot challenge detected; pausing checks for %d seconds instead of retrying aggressively",
                    backoff,
                )
        try:
            dl.close()
        except Exception:
            pass
        loop.call_soon_threadsafe(future.set_result, (False, None))
        return
    except BaseException as exc:
        try:
            dl.close()
        except Exception:
            pass
        loop.call_soon_threadsafe(future.set_exception, exc)
        return

    self._ytdvr_bot_backoff_until = 0.0
    loop.call_soon_threadsafe(future.set_result, (True, (dl, info)))

def _patched_channel_download(self, name: str, arg, loop, future) -> None:
    dl, info = arg
    dl.params["format"] = self.quality or DEFAULT_LIVE_FORMAT
    # Attach patch-private metadata to this YoutubeDL object instead of adding
    # unknown keys to dl.params.
    dl._ytdvr_monitor_url = self.url  # type: ignore[attr-defined]
    dl._ytdvr_channel_params = deepcopy(self.ytdlParams or {})  # type: ignore[attr-defined]
    dl._ytdvr_base_params = _prepared_profile(
        self.ytdlParams,
        youtube=_looks_like_youtube_url(self.url),
        purpose="recording session base profile",
    )  # type: ignore[attr-defined]

    try:
        title = info["description"] if info["title"].find("(live)") != -1 else info["title"]
        rec = RecordingInfo._create_ytdl(
            loop,
            dl,
            info,
            self.getChat,
            self.platform or info["extractor_key"],
            name,
            title,
        )
        loop.call_soon_threadsafe(future.set_result, rec)
    except BaseException as exc:
        loop.call_soon_threadsafe(future.set_exception, exc)


def apply_patch() -> None:
    global _PATCHED, _ORIGINAL_CHANNEL_DOWNLOAD, _ORIGINAL_CHANNEL_CHECK_LIVE, _ORIGINAL_RECORDING_DELETE, _ORIGINAL_RECORDING_DUMP
    if _PATCHED:
        return

    _install_pytchat_fresh_client_fix()

    _ORIGINAL_CHANNEL_DOWNLOAD = channel_mod.Channel._download
    _ORIGINAL_CHANNEL_CHECK_LIVE = channel_mod.Channel._check_live
    _ORIGINAL_RECORDING_DELETE = RecordingInfo.delete
    _ORIGINAL_RECORDING_DUMP = RecordingInfo._dump
    RecordingInfo._ytdlProgress = _patched_progress  # type: ignore[method-assign]
    RecordingInfo._ytdlMain = _patched_ytdl_main  # type: ignore[method-assign]
    RecordingInfo._create_ytdl = classmethod(_patched_create_ytdl)  # type: ignore[method-assign]
    RecordingInfo.delete = _patched_delete  # type: ignore[method-assign]
    RecordingInfo._dump = _patched_dump  # type: ignore[method-assign]
    channel_mod.Channel._check_live = _patched_channel_check_live  # type: ignore[method-assign]
    channel_mod.Channel._download = _patched_channel_download  # type: ignore[method-assign]
    _PATCHED = True
    LOG.info(
        "Loaded yt-dlp dvr reconnect/runtime patch v0.4.30: INFO-only normal offline status, live append to one TS, full PO liveness profile, direct-watch fallback, same-stream reconnect, dual TXT+JSONL chat, optional embedded/burned chat outputs, %ss delay, %ss offline grace",
        RECONNECT_DELAY_SECONDS,
        OFFLINE_GRACE_SECONDS,
    )
