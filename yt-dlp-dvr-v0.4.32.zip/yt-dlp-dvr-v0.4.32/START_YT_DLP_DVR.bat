@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo yt-dlp dvr v0.4.32 - by monjanse7
echo Same livestream = same recording session/file
echo ================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_and_run.ps1"
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" echo Program exited with code %ERR%.
pause
exit /b %ERR%
