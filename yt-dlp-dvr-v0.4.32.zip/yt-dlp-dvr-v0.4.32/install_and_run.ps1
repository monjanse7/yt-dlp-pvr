$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# PowerShell 5.1 can otherwise negotiate older TLS settings against GitHub.
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch {}

function Download-FileRobust {
    param(
        [Parameter(Mandatory=$true)][string]$Url,
        [Parameter(Mandatory=$true)][string]$OutFile,
        [Parameter(Mandatory=$true)][string]$Label,
        [int64]$MinimumBytes = 1024
    )

    $parent = Split-Path -Parent $OutFile
    if ($parent) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }

    # Method 1: Invoke-WebRequest with retries and TLS 1.2 enabled.
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
            Write-Host "Downloading $Label (PowerShell attempt $attempt/3)..."
            Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $OutFile -TimeoutSec 120 -Headers @{"User-Agent"="Mozilla/5.0 yt-dlp-dvr"}
            if ((Test-Path $OutFile) -and (Get-Item $OutFile).Length -ge $MinimumBytes) {
                return
            }
            throw "Downloaded file is missing or too small."
        } catch {
            Write-Warning "PowerShell download attempt $attempt failed: $($_.Exception.Message)"
            if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
            Start-Sleep -Seconds (2 * $attempt)
        }
    }

    # Method 2: Windows 10/11 normally includes curl.exe. It handles GitHub
    # redirects more reliably than Windows PowerShell 5.1 on some systems.
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) {
        try {
            if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
            Write-Host "PowerShell download failed; trying curl.exe for $Label..."
            & $curl.Source -L --fail --retry 5 --retry-delay 3 --connect-timeout 20 -o $OutFile $Url
            if ($LASTEXITCODE -eq 0 -and (Test-Path $OutFile) -and (Get-Item $OutFile).Length -ge $MinimumBytes) {
                return
            }
            throw "curl.exe returned exit code $LASTEXITCODE or produced an invalid file."
        } catch {
            Write-Warning "curl.exe download failed: $($_.Exception.Message)"
            if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
        }
    }

    # Method 3: BITS as a final Windows-native fallback.
    if (Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue) {
        try {
            if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
            Write-Host "curl.exe did not work; trying BITS for $Label..."
            Start-BitsTransfer -Source $Url -Destination $OutFile -ErrorAction Stop
            if ((Test-Path $OutFile) -and (Get-Item $OutFile).Length -ge $MinimumBytes) {
                return
            }
            throw "BITS produced an invalid file."
        } catch {
            Write-Warning "BITS download failed: $($_.Exception.Message)"
            if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
        }
    }

    throw "Could not download $Label after PowerShell, curl.exe, and BITS attempts. Check your internet connection/firewall, then run START_YT_DLP_DVR.bat again. You can also manually place deno.exe in the tools folder."
}

function Find-Python {
    if (Get-Command py -ErrorAction SilentlyContinue) { return @("py", "-3") }
    if (Get-Command python -ErrorAction SilentlyContinue) { return @("python") }
    throw "Python was not found. Install Python 3.11 or newer, then run START_YT_DLP_DVR.bat again."
}

function Ensure-Templates {
    $templateDir = Join-Path $PSScriptRoot "templates"
    New-Item -ItemType Directory -Force -Path $templateDir | Out-Null

    $templateNames = @(
        "404.html",
        "base.html",
        "channel.html",
        "channel_tile.html",
        "channels.html",
        "index.html",
        "settings.html",
        "video.html",
        "video_tile.html"
    )

    foreach ($name in $templateNames) {
        $target = Join-Path $templateDir $name
        if (-not (Test-Path $target) -or (Get-Item $target).Length -lt 10) {
            $url = "https://raw.githubusercontent.com/MCJack123/yt-dvr/refs/tags/0.3.0/templates/$name"
            Write-Host "Downloading yt-dvr template: $name"
            Download-FileRobust -Url $url -OutFile $target -Label "yt-dvr template $name" -MinimumBytes 10
            if (-not (Test-Path $target) -or (Get-Item $target).Length -lt 10) {
                throw "Could not download template $name"
            }
        }
    }
}

$venvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPython)) {
    $py = Find-Python
    Write-Host "Creating local Python environment..."
    if ($py.Count -eq 2) {
        & $py[0] $py[1] -m venv .venv
    } else {
        & $py[0] -m venv .venv
    }
    if ($LASTEXITCODE -ne 0) { throw "Could not create .venv" }

    Write-Host "Installing yt-dvr 0.3.0 + current yt-dlp + YouTube chat support..."
    & $venvPython -m pip install --upgrade pip
    & $venvPython -m pip install "yt-dvr[youtube]==0.3.0" "yt-dlp[default]" imageio-ffmpeg "bgutil-ytdlp-pot-provider==1.3.1" Pillow
    if ($LASTEXITCODE -ne 0) { throw "pip installation failed" }
} else {
    & $venvPython -c "import yt_dlp, imageio_ffmpeg, PIL; import importlib.util; assert importlib.util.find_spec('yt_dvr.__main__'); assert importlib.util.find_spec('yt_dlp_plugins.extractor.getpot_bgutil_script')" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Repairing missing Python packages..."
        & $venvPython -m pip install "yt-dvr[youtube]==0.3.0" "yt-dlp[default]" imageio-ffmpeg "bgutil-ytdlp-pot-provider==1.3.1" Pillow
        if ($LASTEXITCODE -ne 0) { throw "pip repair failed" }
    }
}

# Create the portable plugin layout that yt-dlp explicitly supports for
# PyInstaller/portable builds: <exe-dir>\yt-dlp-plugins\<package>\yt_dlp_plugins.
# Pip/PYTHONPATH plugin discovery is not used by frozen yt-dlp builds.
$portablePluginReady = $false
Write-Host "Preparing portable yt-dlp PO plugin directory..."
& $venvPython (Join-Path $PSScriptRoot "sync_po_plugin.py")
if ($LASTEXITCODE -eq 0) {
    $portablePluginReady = $true
} else {
    Write-Warning "Could not prepare the portable bgutil plugin directory. The program can still start, but Automatic PO Token will stay disabled until this is repaired."
}

Ensure-Templates

# yt-dlp's current YouTube extractor needs a supported JS runtime. Keep a
# portable Deno beside this launcher so nothing must be installed system-wide.
$tools = Join-Path $PSScriptRoot "tools"
$deno = Join-Path $tools "deno.exe"
if (-not (Test-Path $deno)) {
    New-Item -ItemType Directory -Force -Path $tools | Out-Null
    $denoZip = Join-Path $tools "deno.zip"
    $url = "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip"
    Write-Host "Downloading portable Deno for yt-dlp YouTube support..."
    Download-FileRobust -Url $url -OutFile $denoZip -Label "portable Deno" -MinimumBytes 100000
    try {
        Expand-Archive -Force -Path $denoZip -DestinationPath $tools
    } catch {
        Remove-Item -Force $denoZip -ErrorAction SilentlyContinue
        throw "Deno downloaded, but the ZIP could not be extracted: $($_.Exception.Message)"
    }
    Remove-Item -Force $denoZip -ErrorAction SilentlyContinue
    if (-not (Test-Path $deno)) {
        throw "Deno ZIP was extracted, but tools\deno.exe was not found."
    }
}

# Prepare the automatic bgutil PO Token provider. yt-dlp currently recommends
# a provider plugin for the mweb client rather than manually copying PO tokens.
# We use bgutil's script mode so no Docker or always-running second server is
# required. The provider source and its Deno/npm dependencies remain external
# under tools so they can also be reused by a PyInstaller EXE.
$poVersion = "1.3.1"
$poRoot = Join-Path $tools "bgutil-ytdlp-pot-provider-$poVersion"
$poServer = Join-Path $poRoot "server"
$poPlugin = Join-Path $poRoot "plugin"
$poMarker = Join-Path $poServer ".ytdvr-deno-ready-v0.4.32-$poVersion"

if (-not (Test-Path (Join-Path $poServer "package.json"))) {
    $poZip = Join-Path $tools "bgutil-ytdlp-pot-provider-$poVersion.zip"
    $poUrl = "https://github.com/Brainicism/bgutil-ytdlp-pot-provider/archive/refs/tags/$poVersion.zip"
    Write-Host "Downloading bgutil PO Token provider $poVersion..."
    Download-FileRobust -Url $poUrl -OutFile $poZip -Label "bgutil PO Token provider $poVersion" -MinimumBytes 20000
    try {
        Expand-Archive -Force -Path $poZip -DestinationPath $tools
    } catch {
        Remove-Item -Force $poZip -ErrorAction SilentlyContinue
        throw "PO provider downloaded, but the ZIP could not be extracted: $($_.Exception.Message)"
    }
    Remove-Item -Force $poZip -ErrorAction SilentlyContinue
}

# v0.4.31 refreshes the provider dependency tree before Deno installs it.
# bgutil 1.3.1's lockfile can still resolve basic-ftp 5.2.0; that release emits
# a security warning and the upstream warning explicitly says 5.2.1 contains
# the fix. Deno supports package.json overrides, so pin only this transitive
# dependency to the smallest fixed 5.x release instead of jumping to the
# potentially breaking basic-ftp 6.x major. We also request current canvas
# 3.2.3 bug/security fixes. canvas 3.2.3 itself still depends on deprecated
# prebuild-install 7.1.3 upstream, so that separate deprecation cannot be
# safely removed here without replacing/forking canvas.
function Write-Utf8NoBom {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Text
    )
    # Windows PowerShell 5.1 writes a UTF-8 BOM when Set-Content -Encoding UTF8
    # is used. Deno's package.json parser rejects that BOM as an unexpected
    # character at line 1 column 1. Use .NET explicitly so the file is UTF-8
    # without BOM on both Windows PowerShell 5.1 and newer PowerShell versions.
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text, $utf8NoBom)
}

function Update-PoDependencyPolicy {
    param([string]$ServerDir)
    $packageJson = Join-Path $ServerDir "package.json"
    $vendorPackageJson = Join-Path $PSScriptRoot "vendor\bgutil-1.3.1-server-package.json"

    # v0.4.19 could write package.json with a UTF-8 BOM under Windows
    # PowerShell 5.1. That makes Deno report:
    #   Malformed package.json ... expected value at line 1 column 1
    # Always rebuild the manifest from the exact bgutil 1.3.1 upstream baseline
    # bundled with this release. This also repairs an already-corrupted v0.4.19
    # package.json without requiring another GitHub download.
    $sourcePackageJson = $null
    if (Test-Path $vendorPackageJson) {
        $sourcePackageJson = $vendorPackageJson
    } elseif (Test-Path $packageJson) {
        $sourcePackageJson = $packageJson
    } else {
        return $false
    }

    try {
        $raw = [System.IO.File]::ReadAllText($sourcePackageJson)
        $pkg = $raw | ConvertFrom-Json
    } catch {
        Write-Warning "Could not parse bgutil package manifest '$sourcePackageJson': $($_.Exception.Message)"
        return $false
    }

    if (-not $pkg.dependencies) {
        $pkg | Add-Member -MemberType NoteProperty -Name dependencies -Value ([pscustomobject]@{}) -Force
    }
    $pkg.dependencies | Add-Member -MemberType NoteProperty -Name "canvas" -Value "^3.2.3" -Force
    # Pin basic-ftp at the project root as well as in overrides. bgutil's
    # upstream package-lock.json pins 5.2.0, and Deno can seed resolution from
    # an existing npm lockfile. A direct 5.2.1 dependency makes the intended
    # security-fixed version explicit and lets the hoisted tree satisfy
    # get-uri's compatible ^5.0.2 range with the same copy.
    $pkg.dependencies | Add-Member -MemberType NoteProperty -Name "basic-ftp" -Value "5.2.1" -Force

    if (-not $pkg.overrides) {
        $pkg | Add-Member -MemberType NoteProperty -Name overrides -Value ([pscustomobject]@{}) -Force
    }
    $pkg.overrides | Add-Member -MemberType NoteProperty -Name "basic-ftp" -Value "5.2.1" -Force

    $json = $pkg | ConvertTo-Json -Depth 100
    Write-Utf8NoBom -Path $packageJson -Text ($json + [Environment]::NewLine)

    # Validate both JSON syntax and that no UTF-8 BOM slipped back in before
    # Deno is allowed to read the manifest.
    try {
        $bytes = [System.IO.File]::ReadAllBytes($packageJson)
        if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
            throw "package.json still contains a UTF-8 BOM"
        }
        $null = ([System.IO.File]::ReadAllText($packageJson) | ConvertFrom-Json)
    } catch {
        Write-Warning "Generated bgutil package.json failed validation: $($_.Exception.Message)"
        return $false
    }

    Write-Host "  package.json repaired/written as UTF-8 without BOM"
    return $true
}

$poRequiredPackages = @("axios", "form-data", "canvas", "basic-ftp")
function Test-PoRuntimeDependencies {
    param([string]$ServerDir)
    foreach ($pkg in $poRequiredPackages) {
        $manifest = Join-Path $ServerDir "node_modules\$pkg\package.json"
        if (-not (Test-Path $manifest)) { return $false }
    }

    # Validate that the security override was actually honored.
    try {
        $ftpManifest = Get-Content -Raw -Path (Join-Path $ServerDir "node_modules\basic-ftp\package.json") | ConvertFrom-Json
        if ([version]$ftpManifest.version -lt [version]"5.2.1") { return $false }
    } catch {
        return $false
    }
    return $true
}

$poReady = $false
if ((Test-Path (Join-Path $poServer "package.json")) -and (Test-Path $deno)) {
    # A new marker name forces one clean dependency rebuild when upgrading from
    # v0.4.12. Also invalidate it if the copied/runtime tree is incomplete.
    if ((Test-Path $poMarker) -and -not (Test-PoRuntimeDependencies $poServer)) {
        Write-Warning "bgutil node_modules is incomplete; rebuilding it (missing axios/form-data runtime dependency)."
        Remove-Item -Force $poMarker -ErrorAction SilentlyContinue
    }

    if (-not (Test-Path $poMarker)) {
        Write-Host "Preparing bgutil PO Token provider with refreshed dependencies..."
        $oldLocation = Get-Location
        try {
            if (-not (Update-PoDependencyPolicy $poServer)) {
                throw "Could not update bgutil package.json dependency policy."
            }
            Write-Host "  canvas: requested ^3.2.3"
            Write-Host "  basic-ftp: direct-pinned + overridden to 5.2.1 (security-fixed 5.x release)"
            Write-Host "  prebuild-install: upstream canvas dependency; no maintained drop-in replacement is available"

            Set-Location $poServer
            $nodeModules = Join-Path $poServer "node_modules"
            if (Test-Path $nodeModules) {
                Write-Host "Removing stale bgutil node_modules before reinstall..."
                Remove-Item -Recurse -Force $nodeModules
            }

            # bgutil 1.3.1 ships npm/Deno lockfiles that can preserve the old
            # basic-ftp 5.2.0 resolution. Deno documents that a first install
            # may seed its lock data from package-lock.json. Remove both stale
            # lockfiles for this one security refresh so package.json's direct
            # pin + override are resolved from scratch. Deno will regenerate a
            # fresh deno.lock afterwards.
            foreach ($lockName in @("deno.lock", "package-lock.json", "npm-shrinkwrap.json")) {
                $lockPath = Join-Path $poServer $lockName
                if (Test-Path $lockPath) {
                    Write-Host "Removing stale $lockName before dependency refresh..."
                    Remove-Item -Force $lockPath
                }
            }

            # package.json was intentionally changed above, so this one-time
            # refresh must not use --frozen. The hoisted node_modules tree then
            # exposes one basic-ftp 5.2.1 copy for compatible transitive users.
            & $deno install --allow-scripts=npm:canvas --node-modules-linker=hoisted
            if ($LASTEXITCODE -ne 0) {
                throw "Deno dependency installation returned code $LASTEXITCODE"
            }
            if (-not (Test-PoRuntimeDependencies $poServer)) {
                throw "Deno install completed, but required bgutil runtime dependencies are missing or basic-ftp is older than 5.2.1."
            }
            $installedFtp = (Get-Content -Raw -Path (Join-Path $poServer "node_modules\basic-ftp\package.json") | ConvertFrom-Json).version
            $installedCanvas = (Get-Content -Raw -Path (Join-Path $poServer "node_modules\canvas\package.json") | ConvertFrom-Json).version
            Write-Host "Dependency refresh complete: basic-ftp $installedFtp; canvas $installedCanvas"
            New-Item -ItemType File -Force -Path $poMarker | Out-Null
        } catch {
            Remove-Item -Force $poMarker -ErrorAction SilentlyContinue
            Write-Warning "Automatic PO Token provider setup failed: $($_.Exception.Message)"
            Write-Warning "yt-dlp dvr will still start, but automatic PO Token support will be unavailable until START_YT_DLP_DVR.bat can complete this step."
        } finally {
            Set-Location $oldLocation
        }
    }
    if ((Test-Path $poMarker) -and (Test-PoRuntimeDependencies $poServer)) { $poReady = $true }
}

$poReady = $poReady -and $portablePluginReady

if ($poReady) {
    $env:YTDVR_PO_SERVER_HOME = $poServer
    $env:YTDVR_PO_DEFAULT = "1"
    $env:YTDVR_PO_READY = "1"
    $env:YTDVR_DENO_PATH = $deno
    Write-Host "Automatic PO Token files prepared: $poServer"
    Write-Host "Portable yt-dlp plugin: $(Join-Path $PSScriptRoot 'yt-dlp-plugins\bgutil-ytdlp-pot-provider')"
    Write-Host "The launcher will now ask yt-dlp to load the plugin and run the real self-test."
} else {
    $env:YTDVR_PO_DEFAULT = "0"
    Write-Warning "Automatic PO Token provider is not ready; normal yt-dlp mode will be used."
}

# Put an ffmpeg.exe with the expected executable name in tools.
$ffmpegSource = (& $venvPython -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())").Trim()
if ([string]::IsNullOrWhiteSpace($ffmpegSource) -or -not (Test-Path $ffmpegSource)) {
    throw "imageio-ffmpeg did not provide a usable ffmpeg executable."
}
$ffmpegTarget = Join-Path $tools "ffmpeg.exe"
if (-not (Test-Path $ffmpegTarget) -or ((Get-Item $ffmpegTarget).Length -ne (Get-Item $ffmpegSource).Length)) {
    Copy-Item -Force $ffmpegSource $ffmpegTarget
}

$env:PATH = "$tools;$env:PATH"

Write-Host ""
Write-Host "Starting yt-dlp dvr v0.4.32 by monjanse7..."
Write-Host "Config/database are read from: $PSScriptRoot"
Write-Host "Do not start the old yt-dvr.exe at the same time."
Write-Host ""

& $venvPython (Join-Path $PSScriptRoot "run_yt_dlp_dvr.py")
exit $LASTEXITCODE
