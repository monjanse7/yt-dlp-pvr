"""Launcher for yt-dlp dvr, maintained by monjanse7."""
from __future__ import annotations

import os
import sys
import asyncio

VERSION = "0.4.32"
APP_NAME = "yt-dlp dvr"
__author__ = "monjanse7"

# Keep config/database beside this launcher or beside the built EXE.
if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))

os.chdir(APP_DIR)
os.environ.setdefault("YTDVR_CONFIG", os.path.join(APP_DIR, "ytdvr_config.json"))
os.environ.setdefault("YTDVR_DB", os.path.join(APP_DIR, "ytdvr.db"))

PO_PROVIDER_VERSION = "1.3.1"
PO_PROVIDER_ROOT = os.path.join(APP_DIR, "tools", f"bgutil-ytdlp-pot-provider-{PO_PROVIDER_VERSION}")
PO_SERVER_HOME = os.path.join(PO_PROVIDER_ROOT, "server")
PO_READY_MARKER = os.path.join(PO_SERVER_HOME, f".ytdvr-deno-ready-v0.4.32-{PO_PROVIDER_VERSION}")
PORTABLE_PLUGIN_ROOT = os.path.join(APP_DIR, "yt-dlp-plugins", "bgutil-ytdlp-pot-provider")

# Do not claim PO is active merely because provider source files exist. v0.4.13
# enables PO only after yt-dlp's real plugin loader registers bgutil:script-deno,
# Deno 2+ is executable, and the bgutil script files are present.
os.environ.setdefault("YTDVR_PO_DEFAULT", "0")
os.environ.setdefault("YTDVR_PO_PLUGIN_ACTIVE", "0")
if os.path.isdir(PO_SERVER_HOME):
    os.environ.setdefault("YTDVR_PO_SERVER_HOME", PO_SERVER_HOME)

# yt-dvr 0.3.0 uses asyncio.EventLoop in runtime-evaluated type annotations.
if not hasattr(asyncio, "EventLoop"):
    asyncio.EventLoop = asyncio.AbstractEventLoop  # type: ignore[attr-defined]

# Make bundled FFmpeg and Deno discoverable.
if hasattr(sys, "_MEIPASS"):
    bundle_dir = str(sys._MEIPASS)
    os.environ["PATH"] = bundle_dir + os.pathsep + os.environ.get("PATH", "")
    bundled_deno = os.path.join(bundle_dir, "deno.exe")
    if os.path.isfile(bundled_deno):
        os.environ.setdefault("YTDVR_DENO_PATH", bundled_deno)
else:
    tools_deno = os.path.join(APP_DIR, "tools", "deno.exe")
    if os.path.isfile(tools_deno):
        os.environ.setdefault("YTDVR_DENO_PATH", tools_deno)
        os.environ["PATH"] = os.path.dirname(tools_deno) + os.pathsep + os.environ.get("PATH", "")
    try:
        import imageio_ffmpeg
        ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
        os.environ["PATH"] = os.path.dirname(ffmpeg_exe) + os.pathsep + os.environ.get("PATH", "")
    except Exception:
        pass

# Plugin/runtime readiness self-test. The official yt-dlp plugin loader searches
# <exe-dir>/yt-dlp-plugins for frozen portable builds. v0.4.13 deliberately avoids
# calling bgutil provider.is_available() with a synthetic extractor because that
# caused the false NOT READY result seen with a valid Deno 2.9.5 setup.
from po_self_test import run_po_self_test

po_result = run_po_self_test(
    server_home=PO_SERVER_HOME if os.path.isdir(PO_SERVER_HOME) else None,
    deno_path=os.environ.get("YTDVR_DENO_PATH"),
    verbose=True,
)
if po_result.active and os.path.isfile(PO_READY_MARKER):
    os.environ["YTDVR_PO_PLUGIN_ACTIVE"] = "1"
    os.environ["YTDVR_PO_READY"] = "1"
    os.environ["YTDVR_PO_DEFAULT"] = "1"
else:
    os.environ["YTDVR_PO_PLUGIN_ACTIVE"] = "0"
    os.environ["YTDVR_PO_READY"] = "0"
    os.environ["YTDVR_PO_DEFAULT"] = "0"

if "--po-self-test-only" in sys.argv:
    raise SystemExit(0 if os.environ.get("YTDVR_PO_PLUGIN_ACTIVE") == "1" else 2)

from reconnect_patch import apply_patch, install_manual_finalize_api
apply_patch()

# yt-dvr 0.3.0 keeps its HTML templates outside the Python package.
def _configure_web_templates() -> None:
    if hasattr(sys, "_MEIPASS"):
        template_dir = os.path.join(str(sys._MEIPASS), "templates")
    else:
        template_dir = os.path.join(APP_DIR, "templates")

    if not os.path.isdir(template_dir):
        print(f"WARNING: upstream yt-dvr web templates were not found: {template_dir}")
        return

    try:
        from jinja2 import FileSystemLoader
        import yt_dvr.app as app_mod

        app_mod.app.template_folder = template_dir
        app_mod.app.jinja_env.loader = FileSystemLoader(template_dir)
        print(f"Web templates: {template_dir}")
    except Exception as exc:
        print(f"WARNING: Could not configure upstream yt-dvr web templates: {exc}")

_configure_web_templates()
install_manual_finalize_api()

if "--generate-missing-chat-overlays" in sys.argv:
    from generate_missing_chat_overlays import main as generate_missing_chat_overlays_main
    raise SystemExit(generate_missing_chat_overlays_main())

from yt_dvr.__main__ import main_cli

if __name__ == "__main__":
    print(f"{APP_NAME} v{VERSION} — by {__author__}")
    print(f"Config/database directory: {APP_DIR}")
    if os.environ.get("YTDVR_PO_PLUGIN_ACTIVE") == "1":
        print(f"PO Token provider: bgutil {PO_PROVIDER_VERSION} ACTIVE (mweb default)")
    else:
        print("WARNING: Automatic PO Token is disabled because the provider self-test did not pass.")
        if getattr(sys, "frozen", False) and not os.path.isdir(PORTABLE_PLUGIN_ROOT):
            print(f"Expected portable plugin folder: {PORTABLE_PLUGIN_ROOT}")
    main_cli()
