@echo off
setlocal
cd /d "%~dp0"
set "YTDVR_CONFIG=%CD%\ytdvr_config.json"
set "YTDVR_DB=%CD%\ytdvr.db"
if exist "%CD%\tools\deno.exe" set "PATH=%CD%\tools;%PATH%"

echo WARNING: This will replace existing generated chat-track/chat-overlay files.
echo The original recording and chat JSONL are not modified.
echo.

if exist "%CD%\dist\yt-dlp-dvr.exe" (
  "%CD%\dist\yt-dlp-dvr.exe" --generate-missing-chat-overlays --force
  set "RC=%ERRORLEVEL%"
) else if exist "%CD%\.venv\Scripts\python.exe" (
  "%CD%\.venv\Scripts\python.exe" "%CD%\generate_missing_chat_overlays.py" --force
  set "RC=%ERRORLEVEL%"
) else (
  echo Python environment not found. Run START_YT_DLP_DVR.bat once first.
  set "RC=2"
)

echo.
if "%RC%"=="0" (
  echo Chat overlay regeneration finished.
) else (
  echo Chat overlay regeneration failed with code %RC%.
)
pause
exit /b %RC%
