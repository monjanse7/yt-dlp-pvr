"""Generate missing chat-derived video outputs for yt-dlp dvr recordings.

v0.4.31 can recover from an empty/new ytdvr.db by scanning config.saveDir for
*.chat.jsonl sidecars and pairing them with the completed video that has the
same basename. This is useful after moving to a new yt-dlp-dvr folder or
when the database was not copied along with the recordings.
"""
from __future__ import annotations

import asyncio
import os
import sqlite3
import sys
from copy import deepcopy
from dataclasses import dataclass
from typing import Iterable

if not hasattr(asyncio, "EventLoop"):
    asyncio.EventLoop = asyncio.AbstractEventLoop  # type: ignore[attr-defined]

_VIDEO_EXTENSIONS = (".mp4", ".mkv", ".mov", ".m4v", ".webm", ".ts")


@dataclass
class FsCandidate:
    channel: str
    title: str
    timestamp: int
    filename: str
    chat_filename: str


def _norm_rel(path: str) -> str:
    return path.replace("\\", "/")


def _find_source_for_jsonl(jsonl_path: str) -> str | None:
    suffix = ".chat.jsonl"
    if not jsonl_path.lower().endswith(suffix):
        return None
    base = jsonl_path[: -len(suffix)]
    # Prefer the common final/remux containers, then raw TS as a fallback.
    for ext in _VIDEO_EXTENSIONS:
        candidate = base + ext
        if os.path.isfile(candidate) and os.path.getsize(candidate) > 0:
            return candidate
    return None


def _resolve_channel(folder_hint: str, channels: dict) -> str:
    if folder_hint in channels:
        return folder_hint
    lower = folder_hint.casefold()
    for key in channels:
        if str(key).casefold() == lower:
            return str(key)
    # Folder names are normally channel keys. If only one configured channel
    # has chat-video output enabled, it is a safe fallback for moved recordings.
    enabled: list[str] = []
    import reconnect_patch

    for key, channel_obj in channels.items():
        params = getattr(channel_obj, "ytdlParams", None) or {}
        opts = reconnect_patch._special_ytdvr_options(params)
        if opts["chat_embed_track"] or opts["chat_burn_overlay"]:
            enabled.append(str(key))
    if len(enabled) == 1:
        return enabled[0]
    return folder_hint


def _filesystem_candidates(save_dir: str, channels: dict) -> Iterable[FsCandidate]:
    if not os.path.isdir(save_dir):
        return []

    found: list[FsCandidate] = []
    for root, _dirs, files in os.walk(save_dir):
        for name in files:
            if not name.lower().endswith(".chat.jsonl"):
                continue
            jsonl_path = os.path.join(root, name)
            source = _find_source_for_jsonl(jsonl_path)
            if source is None:
                continue

            rel_source = _norm_rel(os.path.relpath(source, save_dir))
            rel_jsonl = _norm_rel(os.path.relpath(jsonl_path, save_dir))
            jsonl_suffix = ".chat.jsonl"
            rel_base = rel_jsonl[: -len(jsonl_suffix)]
            rel_txt = rel_base + ".txt"
            first_part = rel_source.split("/", 1)[0] if "/" in rel_source else ""
            channel = _resolve_channel(first_part, channels)
            title = os.path.basename(rel_base)
            try:
                timestamp = int(os.path.getmtime(source))
            except OSError:
                timestamp = 0
            found.append(FsCandidate(channel, title, timestamp, rel_source, rel_txt))
    return found


def _options_for_recording(rec, config, reconnect_patch):
    current = config.channels.get(rec.channel) if isinstance(config.channels, dict) else None
    rec._ytdvr_channel_params = deepcopy(getattr(current, "ytdlParams", None) or {})  # type: ignore[attr-defined]
    return reconnect_patch._special_ytdvr_options(reconnect_patch._effective_channel_params(rec))


def main() -> int:
    force = "--force" in sys.argv[1:]
    # Force progress to plain stdout so it remains visible even when yt-dvr's
    # logger is configured above INFO. This is especially important before
    # FFmpeg starts, while rich chat PNG frames are being prepared.
    os.environ["YTDVR_CHAT_PROGRESS_STDOUT"] = "1"
    from yt_dvr.config import config
    from yt_dvr.channel import RecordingInfo
    import reconnect_patch

    config_path = os.environ.get("YTDVR_CONFIG") or os.path.join(os.getcwd(), "ytdvr_config.json")
    db_path = os.environ.get("YTDVR_DB") or os.path.join(os.getcwd(), "ytdvr.db")
    config.load(config_path)
    save_dir = os.path.abspath(config.saveDir)

    print(f"Config: {os.path.abspath(config_path)}")
    print(f"Database: {os.path.abspath(db_path)}")
    print(f"Recording folder: {save_dir}")
    if force:
        print("Mode: FORCE REGENERATE existing requested chat outputs")

    rows = []
    db = None
    try:
        db = sqlite3.connect(db_path)
        cur = db.cursor()
        rows = cur.execute(
            "SELECT platform, channel, title, timestamp, url, filename, chat_filename, in_progress FROM videos"
        ).fetchall()
    except sqlite3.Error as exc:
        print(f"Database scan unavailable ({exc}); continuing with filesystem recovery scan.")

    candidates = 0
    generated_before = 0
    attempted = 0
    processed_now = 0
    failed_now = 0
    processed_sources: set[str] = set()

    print(f"Database recordings found: {len(rows)}")

    def process(rec) -> None:
        nonlocal candidates, generated_before, attempted, processed_now, failed_now
        opts = _options_for_recording(rec, config, reconnect_patch)
        if not (opts["chat_embed_track"] or opts["chat_burn_overlay"]):
            return

        source_key = _norm_rel(rec.filename).casefold()
        processed_sources.add(source_key)
        candidates += 1
        track_rel, overlay_rel = reconnect_patch._chat_derived_relpaths(rec.filename)
        requested_paths = []
        if opts["chat_embed_track"]:
            requested_paths.append(reconnect_patch._chat_abs_path(track_rel))
        if opts["chat_burn_overlay"]:
            requested_paths.append(reconnect_patch._chat_abs_path(overlay_rel))
        if requested_paths and all(os.path.isfile(path) for path in requested_paths) and not force:
            generated_before += 1
            return
        if force:
            for path in requested_paths:
                try:
                    if os.path.isfile(path):
                        os.remove(path)
                except OSError as exc:
                    print(f"  warning: could not remove old output {path}: {exc}")

        print(f"{'Regenerating' if force else 'Generating missing'} chat output(s): {rec.channel} | {rec.title}")
        print(f"  source: {reconnect_patch._chat_abs_path(rec.filename)}")
        print(f"  chat:   {reconnect_patch._chat_abs_path(reconnect_patch._chat_jsonl_path(rec.chat_filename))}")
        attempted += 1
        reconnect_patch._postprocess_chat_outputs(rec)
        if requested_paths and all(os.path.isfile(path) and os.path.getsize(path) > 0 for path in requested_paths):
            processed_now += 1
            print("  result: SUCCESS")
        else:
            failed_now += 1
            print("  result: FAILED (requested output file was not created)")

    # First use proper database metadata when available.
    for platform, channel, title, timestamp, url, filename, chat_filename, in_progress in rows:
        if in_progress or not chat_filename:
            continue
        rec = RecordingInfo(platform, channel, title, timestamp, url, filename, chat_filename, False)
        process(rec)

    # v0.4.31 recovery path: a new install often has a new/empty ytdvr.db while
    # recordings and chat JSONL files still live in saveDir. Pair by basename.
    fs_rows = list(_filesystem_candidates(save_dir, config.channels if isinstance(config.channels, dict) else {}))
    print(f"Filesystem chat/video pairs found: {len(fs_rows)}")
    for item in fs_rows:
        if _norm_rel(item.filename).casefold() in processed_sources:
            continue
        rec = RecordingInfo(
            "Youtube",
            item.channel,
            item.title,
            item.timestamp,
            "",
            item.filename,
            item.chat_filename,
            False,
        )
        process(rec)

    if db is not None:
        db.close()

    print(
        f"Done. Matching completed recordings: {candidates}; "
        f"already complete: {generated_before}; attempted now: {attempted}; "
        f"created now: {processed_now}; failed now: {failed_now}."
    )
    if not fs_rows and not rows:
        print("No recordings were found in either the database or the recording folder shown above.")
        print("If your videos are elsewhere, set Save directory to that folder in yt-dlp dvr Settings and run this again.")
    return 1 if failed_now else 0


if __name__ == "__main__":
    raise SystemExit(main())
