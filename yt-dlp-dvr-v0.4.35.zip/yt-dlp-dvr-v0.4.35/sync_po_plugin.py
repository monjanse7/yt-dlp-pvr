"""Create a portable yt-dlp plugin copy beside yt-dlp dvr.

This is required for PyInstaller builds: yt-dlp does not search pip/PYTHONPATH
plugin locations when frozen, but it does search <exe-dir>/yt-dlp-plugins/.
"""
from __future__ import annotations

import importlib.util
import shutil
import sys
from pathlib import Path

PACKAGE_NAME = "bgutil-ytdlp-pot-provider"
MODULE_NAME = "yt_dlp_plugins.extractor.getpot_bgutil_script"
REQUIRED = (
    "extractor/getpot_bgutil.py",
    "extractor/getpot_bgutil_script.py",
    "extractor/getpot_bgutil_http.py",
)


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def main() -> int:
    spec = importlib.util.find_spec(MODULE_NAME)
    if spec is None or not spec.origin:
        print(f"ERROR: Could not locate installed {PACKAGE_NAME} Python plugin.")
        return 2

    source_file = Path(spec.origin).resolve()
    # .../yt_dlp_plugins/extractor/getpot_bgutil_script.py -> yt_dlp_plugins
    try:
        source_ns = source_file.parents[1]
    except IndexError:
        print(f"ERROR: Unexpected plugin module path: {source_file}")
        return 3

    missing = [rel for rel in REQUIRED if not (source_ns / rel).is_file()]
    if missing:
        print("ERROR: Installed bgutil plugin is incomplete; missing: " + ", ".join(missing))
        return 4

    root = app_dir()
    package_root = root / "yt-dlp-plugins" / PACKAGE_NAME
    dest_ns = package_root / "yt_dlp_plugins"

    if dest_ns.exists():
        shutil.rmtree(dest_ns)
    package_root.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        source_ns,
        dest_ns,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
    )

    missing_after = [rel for rel in REQUIRED if not (dest_ns / rel).is_file()]
    if missing_after:
        print("ERROR: Portable plugin copy failed; missing: " + ", ".join(missing_after))
        return 5

    print(f"Portable yt-dlp PO plugin synced: {package_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
