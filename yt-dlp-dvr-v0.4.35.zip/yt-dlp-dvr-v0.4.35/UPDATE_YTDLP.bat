@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run START_YT_DLP_DVR.bat once first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install --upgrade "yt-dlp[default]" "bgutil-ytdlp-pot-provider==1.3.1"
if errorlevel 1 (
  echo Update failed.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" "%~dp0sync_po_plugin.py"
if errorlevel 1 (
  echo yt-dlp updated, but the portable PO plugin copy could not be refreshed.
  pause
  exit /b 2
)
echo.
echo yt-dlp + PO provider update finished and portable yt-dlp-plugins copy refreshed.
echo The provider server remains pinned to matching v1.3.1.
pause
