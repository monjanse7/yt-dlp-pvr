"""Non-network self-test for the bgutil yt-dlp PO Token provider.

v0.4.13 intentionally does *not* call the provider's internal is_available()
method. That method is an implementation detail and, with bgutil 1.3.1, can
report unavailable when called with a synthetic InfoExtractor even though
yt-dlp has correctly registered the Deno provider and Deno itself is usable.

The startup gate therefore checks only the stable prerequisites needed before
yt-dlp can use the provider for real requests:
  * yt-dlp discovers/registers bgutil:script-deno
  * Deno exists and is version 2+
  * bgutil server_home exists and contains src/generate_once.ts
  * the copied Deno runtime tree contains axios + form-data

The launcher separately requires the .ytdvr-deno-ready marker created after
`deno install` succeeds. Actual token generation remains yt-dlp/bgutil's job
when a YouTube request is made.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
import re
import subprocess


@dataclass
class PoSelfTestResult:
    active: bool = False
    providers: list[str] = field(default_factory=list)
    plugin_directories: list[str] = field(default_factory=list)
    deno_version: str | None = None
    provider_script: str | None = None
    reason: str | None = None


def _deno_version(deno_path: str) -> tuple[str | None, str | None]:
    try:
        proc = subprocess.run(
            [deno_path, "--version"],
            capture_output=True,
            text=True,
            timeout=8,
            check=False,
        )
    except Exception as exc:
        return None, f"Deno could not be started: {exc}"

    text = (proc.stdout or proc.stderr or "").strip()
    first = text.splitlines()[0] if text else ""
    match = re.search(r"\bdeno\s+(\d+(?:\.\d+){1,3})", first, re.I)
    if proc.returncode != 0 or not match:
        return None, f"Deno version check failed (code {proc.returncode}): {first or 'no output'}"

    version = match.group(1)
    try:
        major = int(version.split(".", 1)[0])
    except ValueError:
        major = 0
    if major < 2:
        return version, f"Deno {version} is too old; bgutil 1.3.1 requires Deno >= 2.0.0"
    return version, None


def run_po_self_test(*, server_home: str | None, deno_path: str | None, verbose: bool = True) -> PoSelfTestResult:
    result = PoSelfTestResult()

    if verbose:
        print("PO Token self-test...")

    # 1) Make yt-dlp run its real plugin loader, then inspect its PO registry.
    try:
        from yt_dlp.plugins import directories, load_all_plugins
        load_all_plugins()
        result.plugin_directories = [str(p) for p in (directories() or [])]
    except Exception as exc:
        result.reason = f"yt-dlp plugin loader failed: {exc}"
        if verbose:
            print(f"PO STATUS: NOT LOADED - {result.reason}")
        return result

    try:
        from yt_dlp.extractor.youtube.pot._registry import _pot_providers
        provider_classes = list(_pot_providers.value.values())
    except Exception as exc:
        result.reason = f"Could not inspect yt-dlp PO provider registry: {exc}"
        if verbose:
            print(f"PO STATUS: NOT LOADED - {result.reason}")
        return result

    provider_by_name: dict[str, type] = {}
    for cls in provider_classes:
        name = str(getattr(cls, "PROVIDER_NAME", getattr(cls, "__name__", "unknown")))
        version = str(getattr(cls, "PROVIDER_VERSION", "?"))
        provider_by_name[name] = cls
        if name.startswith("bgutil:"):
            result.providers.append(f"{name}-{version}")

    if verbose and result.plugin_directories:
        for path in result.plugin_directories:
            lower = path.lower()
            if "yt-dlp-plugins" in lower or "site-packages" in lower:
                print(f"  plugin path: {path}")

    if not result.providers:
        result.reason = "bgutil provider classes were not registered by yt-dlp"
        if verbose:
            print("  registered bgutil providers: none")
            print(f"PO STATUS: NOT LOADED - {result.reason}")
        return result

    if verbose:
        print("  registered providers: " + ", ".join(result.providers))

    # The provider we actually configure in reconnect_patch.py is script-deno.
    if "bgutil:script-deno" not in provider_by_name:
        result.reason = "bgutil:script-deno was not registered by yt-dlp"
        if verbose:
            print(f"PO STATUS: NOT LOADED - {result.reason}")
        return result

    # 2) Verify the real Deno executable, without invoking provider internals.
    if not deno_path or not os.path.isfile(deno_path):
        result.reason = f"Deno executable is missing: {deno_path or '(not configured)'}"
        if verbose:
            print(f"PO STATUS: NOT READY - {result.reason}")
        return result

    result.deno_version, deno_error = _deno_version(deno_path)
    if deno_error:
        result.reason = deno_error
        if verbose:
            print(f"PO STATUS: NOT READY - {result.reason}")
        return result
    if verbose:
        print(f"  Deno: {result.deno_version} (OK, >= 2.0.0)")

    # 3) Verify the external bgutil script files used by script-deno.
    if not server_home:
        result.reason = "bgutil server_home is not configured"
        if verbose:
            print(f"PO STATUS: NOT READY - {result.reason}")
        return result

    server_path = Path(server_home)
    script = server_path / "src" / "generate_once.ts"
    result.provider_script = str(script)
    if not script.is_file():
        result.reason = f"bgutil Deno provider script is missing: {script}"
        if verbose:
            print(f"PO STATUS: NOT READY - {result.reason}")
        return result

    package_json = server_path / "package.json"
    if not package_json.is_file():
        result.reason = f"bgutil server package.json is missing: {package_json}"
        if verbose:
            print(f"PO STATUS: NOT READY - {result.reason}")
        return result

    # Stable filesystem check for the exact runtime dependency that made the
    # v0.4.12 frozen self-test fail after copying the provider tree. We do not
    # execute generate_once.ts here; this just proves the portable node_modules
    # tree is complete enough for axios' Node FormData adapter to resolve.
    for package_name in ("axios", "form-data", "basic-ftp"):
        manifest = server_path / "node_modules" / package_name / "package.json"
        if not manifest.is_file():
            result.reason = f"bgutil runtime dependency is missing: {manifest}"
            if verbose:
                print(f"PO STATUS: NOT READY - {result.reason}")
            return result

    # v0.4.31 keeps readiness consistent with the installer: do not report PO
    # ACTIVE if the security refresh failed and basic-ftp is still 5.2.0.
    try:
        import json
        ftp_manifest = server_path / "node_modules" / "basic-ftp" / "package.json"
        ftp_version = json.loads(ftp_manifest.read_text(encoding="utf-8-sig")).get("version", "0")
        parts = tuple(int(x) for x in str(ftp_version).split(".")[:3])
        if parts < (5, 2, 1):
            result.reason = f"basic-ftp {ftp_version} is older than required security-fixed 5.2.1"
            if verbose:
                print(f"PO STATUS: NOT READY - {result.reason}")
            return result
    except Exception as exc:
        result.reason = f"could not verify basic-ftp version: {exc}"
        if verbose:
            print(f"PO STATUS: NOT READY - {result.reason}")
        return result

    result.active = True
    if verbose:
        print(f"  provider script: {script}")
        print("PO STATUS: ACTIVE (script-deno registered; Deno >= 2; bgutil files + runtime deps ready)")
        print("  Note: this is a non-network readiness test; yt-dlp will request/generate a PO token when needed.")
    return result
