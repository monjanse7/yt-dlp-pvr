@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run START_YT_DLP_DVR.bat once first.
  pause
  exit /b 1
)
set "YTDVR_DENO_PATH=%~dp0tools\deno.exe"
set "YTDVR_PO_SERVER_HOME=%~dp0tools\bgutil-ytdlp-pot-provider-1.3.1\server"
".venv\Scripts\python.exe" -c "from po_self_test import run_po_self_test; import os,sys; r=run_po_self_test(server_home=os.environ.get('YTDVR_PO_SERVER_HOME'), deno_path=os.environ.get('YTDVR_DENO_PATH'), verbose=True); sys.exit(0 if r.active else 2)"
set ERR=%ERRORLEVEL%
echo.
if "%ERR%"=="0" (
  echo PO self-test PASSED.
) else (
  echo PO self-test FAILED with code %ERR%.
)
pause
exit /b %ERR%
